# Design Brief

## Tone
**Enterprise Data Analytics** — professional, authoritative, Bloomberg Terminal meets modern SaaS. Dark-mode first (eye-friendly for long sessions), data-forward, trustworthy.

## Visual Direction
Analytical yet accessible. Dark theme optimizes for visual scanning of numeric data. Blue primary evokes trust and analytics; teal accent highlights positive insights (cross-sell wins). High contrast ensures readability of transaction tables and charts. Geometric sans-serif typography (General Sans) for headers, monospace for data (Geist Mono). Extended with specialized component styling for network graphs, heatmaps, RFM segments, and explainable AI patterns.

## Color Palette

| Token                | Light                | Dark                 | Usage                            |
|:-------------------- |:-------------------- |:-------------------- |:-------------------------------- |
| Primary              | `0.52 0.21 264` (blue) | `0.62 0.2 264`    | Buttons, links, primary UI       |
| Secondary            | `0.45 0.05 264` (slate) | `0.25 0.08 264` | Backgrounds, neutral states      |
| Accent               | `0.62 0.18 187` (teal) | `0.68 0.2 187`  | Success, insights, cross-sells   |
| Destructive          | `0.55 0.22 25` (red) | `0.65 0.19 22`   | Errors, alerts, actions to avoid |
| Chart-1 (Teal)       | `0.62 0.18 187` | `0.68 0.2 187`      | Primary data series              |
| Chart-2 (Blue)       | `0.52 0.21 264` | `0.62 0.2 264`      | Secondary data series            |
| Chart-3 (Indigo)     | `0.65 0.16 300` | `0.68 0.18 300`     | Tertiary data series             |
| Chart-4 (Amber)      | `0.58 0.19 50` | `0.68 0.2 50`       | Warm highlights                  |
| Chart-5 (Green)      | `0.72 0.15 100` | `0.78 0.17 100`     | Positive/growth indicators       |
| RFM-Champions (Teal) | `0.62 0.18 187` | `0.68 0.2 187`  | Top-value customer segment       |
| RFM-Loyal (Blue)     | `0.52 0.21 264` | `0.62 0.2 264`  | Repeat, engaged customers        |
| RFM-At-Risk (Amber)  | `0.58 0.19 50` | `0.68 0.2 50`   | Declining engagement segment     |
| RFM-Lost (Red)       | `0.55 0.22 25` | `0.65 0.19 22`  | Inactive/churned customers       |
| Heatmap-Cold (Slate) | `0.45 0.05 264` | `0.25 0.08 264` | Low correlation/support (cool)   |
| Heatmap-Warm (Gold)  | `0.65 0.14 45` | `0.58 0.18 45`  | Medium correlation intensity     |
| Heatmap-Hot (Teal)   | `0.62 0.18 187` | `0.68 0.2 187`  | High correlation/support (peak)  |

## Structural Zones

| Zone                    | Background                          | Border                | Depth                             | Purpose                                    |
|:----------------------- |:----------------------------------- |:--------------------- |:--------------------------------- |:------------------------------------------ |
| Sidebar (Left Nav)      | `--sidebar` (light/dark neutral)   | `--sidebar-border`    | Elevated, static anchor           | Navigation, user menu, filters             |
| Header/Title Bar        | `--background`                     | `border-b border-border` | Minimal, reads as same as body   | Page title, primary actions, search        |
| Main Content Grid       | `--background` (alternating cards) | `border border-border` | Card elevation: `shadow-elevated` | Analytics data, charts, tables             |
| Data Cards              | `--card`                           | `border border-border` | `shadow-elevated`                | KPIs, metric summaries, recommendations    |
| Data Tables             | `--card`                           | `border-b data-cell`  | Row striping: `data-row-alt`      | Association rules, transactions, details   |
| Footer/Actions          | `--secondary` with opacity         | `border-t border-border` | Subtle background                | Pagination, export, filters               |
| Graph Visualization     | `--background`                     | Canvas/SVG elements   | Node shadow: `shadow-graph-node`  | Force-directed product networks            |
| Heatmap Container       | `--card`                           | `border border-border` | Cell-level depth via color       | Correlation matrix visualization           |
| RFM Segment Panel       | `--secondary/20`                   | `border border-border` | Badge: tinted backgrounds       | Customer segment labels, metrics           |
| Chat Widget             | `--card`                           | `border border-border` | Bubbles float above             | NLP bot, user queries, responses            |
| Alert Panel             | Severity-tinted backgrounds         | Severity borders      | Icon prefix, text right          | Smart alerts, warnings, notifications     |
| Explainability Panel    | `--secondary/10`                   | `border border-border` | Nested below recommendation      | Rule details, confidence bar, metrics      |

## Typography

| Role             | Font          | Size    | Weight | Usage                                  |
|:---------------- |:------------- |:------- |:------ |:-------------------------------------- |
| Display          | General Sans  | 32px    | 600    | Page titles, dashboard headers         |
| Heading (H2)     | General Sans  | 20px    | 600    | Section headers, card titles           |
| Body             | Geist Mono    | 14px    | 400    | Body text, table data, descriptions    |
| Label            | Geist Mono    | 12px    | 400    | Form labels, column headers, metadata  |
| Metric Value     | Geist Mono    | 24px    | 600    | KPI numbers, key statistics            |
| Mono             | Geist Mono    | 12px    | 400    | Transaction IDs, product codes, APIs   |

## Component Patterns

| Component | Style | Behavior |
|:--- |:--- |:--- |
| Graph Nodes | Fill: `primary`, Stroke: `border`, Hover: `accent` fill + `stroke-2` | Clickable, highlight edges on hover |
| Graph Edges | Stroke: `border` `opacity-40`, Weighted by lift thickness | Highlight on node hover (`opacity-100`, `stroke-accent`) |
| Heatmap Cells | Cold: `secondary`, Warm: `amber`, Hot: `accent`, Rounded: `rounded-sm` | Intensity via OKLCH lightness and cell color |
| Chatbot User | Background: `primary`, Foreground: `primary-foreground`, Margin: `ml-auto`, Max-width: `max-w-xs` | Aligned right, monospace for metrics |
| Chatbot Assistant | Background: `secondary`, Foreground: `secondary-foreground`, Margin: `mr-auto`, Max-width: `max-w-md` | Aligned left, monospace for data |
| RFM Badges | Inline flex, `px-3 py-1`, `rounded-sm`, text tinted to segment color | Champions/Loyal/At-Risk/Lost via `.badge-{segment}` |
| Alert Cards | Background: tint of severity color (`**/10`), Border: severity color (`**/30`) | Info: blue, Warning: amber, Critical: red |
| Explainability Panel | Background: `secondary/10`, Border: `border-border`, Nested below card, Monospace metrics | Shows rule, confidence bar, support/lift |

## Motion
- **Transitions**: `transition-smooth` (0.3s cubic-bezier) for state changes (hover, click, expand).
- **Entrance**: `animate-fade-in` (200ms) for modals, `animate-slide-in-right` (300ms) for panels.
- **Focus states**: Ring outline using `--ring` color with 2px width.
- **No jank**: Reduce motion respected; animations disabled for `prefers-reduced-motion`.

## Spacing & Rhythm
- **Baseline grid**: 4px for fine detail, 8px for components, 16px for sections.
- **Card padding**: 16px for compact, 24px for spacious content.
- **Gap between sections**: 24px–32px for visual breathing room.
- **Density**: Data tables compact (12px padding), dashboards relaxed (20px gaps).

## Differentiation
**High-contrast data readability + explainable AI** — tables and charts prioritize clarity over decoration. Monospace body font signals "data context". Sidebar remains always visible (no hamburger collapse to distraction). Accent color (teal) creates an "insight moment" — when users see a high-confidence cross-sell rule or a strong association, the accent color draws attention to the win. Extended components (graph, heatmap, RFM, chatbot, explainability) maintain dark-theme professionalism while serving specialized analytical workflows.

## Constraints & Anti-Patterns
✗ No gradients as backgrounds; depth comes from elevation shadows only.
✗ No rainbow palettes; 5 chart colors max, coordinated hues.
✗ No decorative animations; motion serves usability only.
✗ No custom fonts in data cells; Geist Mono for legibility.
✗ Tables never use full row background; row hover or subtle stripe only.
✗ Avoid rounded corners > 8px; keep professional sharpness.
✗ Graph nodes/edges never glow; use opacity and stroke weight only.
✗ Heatmap cells capped at `rounded-sm`; maintain grid clarity.
