import CommonTypes "common";

module {
  public type AssociationRule = {
    id : CommonTypes.RuleId;
    datasetId : CommonTypes.DatasetId;
    antecedent : Text;
    consequent : Text;
    support : Float;
    confidence : Float;
    lift : Float;
  };

  public type Recommendation = {
    product : Text;
    lift : Float;
    confidence : Float;
    support : Float;
  };

  public type ProductPair = {
    productA : Text;
    productB : Text;
    coOccurrences : Nat;
    support : Float;
  };

  public type DashboardStats = {
    totalDatasets : Nat;
    totalTransactions : Nat;
    totalRules : Nat;
    totalProducts : Nat;
    avgLift : Float;
    topProducts : [Text];
  };

  public type ComputeRulesParams = {
    datasetId : CommonTypes.DatasetId;
    minSupport : Float;
    minConfidence : Float;
  };
};
