module {
  public type Timestamp = Int;
  public type DatasetId = Nat;
  public type RuleId = Nat;
  public type UserId = Principal;

  public type UserRole = {
    #admin;
    #analyst;
    #viewer;
  };

  public type AlgorithmType = {
    #apriori;
    #fpGrowth;
    #collaborative;
    #sequence;
  };

  public type ComputationResult<T> = {
    success : Bool;
    data : ?T;
    errorMsg : ?Text;
    computedAt : Timestamp;
    algorithm : AlgorithmType;
    durationMs : Nat;
  };
};
