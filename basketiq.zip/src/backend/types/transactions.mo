import CommonTypes "common";

module {
  public type Transaction = {
    id : Nat;
    products : [Text];
    timestamp : CommonTypes.Timestamp;
    uploadedBy : CommonTypes.UserId;
  };

  public type TransactionDataset = {
    id : CommonTypes.DatasetId;
    name : Text;
    recordCount : Nat;
    uploadTimestamp : CommonTypes.Timestamp;
    uploadedBy : CommonTypes.UserId;
  };

  public type TransactionInput = {
    products : [Text];
  };
};
