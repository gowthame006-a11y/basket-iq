import List "mo:core/List";
import Map "mo:core/Map";
import Time "mo:core/Time";
import Principal "mo:core/Principal";
import AccessControl "mo:caffeineai-authorization/access-control";
import MixinAuthorization "mo:caffeineai-authorization/MixinAuthorization";
import CommonTypes "types/common";
import TxTypes "types/transactions";
import AnalyticsTypes "types/analytics";
import AlertTypes "types/alerts";
import AuditTypes "types/audit";
import ChatTypes "types/chatbot";
import SettingsTypes "types/settings";
import InventoryTypes "types/inventory";
import ABTestingTypes "types/abtesting";
import TransactionsMixin "mixins/transactions-api";
import AnalyticsMixin "mixins/analytics-api";
import UsersMixin "mixins/users-api";
import AlertsMixin "mixins/alerts-api";
import AuditMixin "mixins/audit-api";
import ChatbotMixin "mixins/chatbot-api";
import AdminMixin "mixins/admin-api";
import TransactionsLib "lib/transactions";
import Migration "migration";

(with migration = Migration.run)
actor {
  let accessControlState = AccessControl.initState();
  include MixinAuthorization(accessControlState);

  // ── Counter state ──────────────────────────────────────────────────────────
  let nextDatasetId = { var value : Nat = 1 };
  let nextRuleId = { var value : Nat = 1 };
  let nextAlertId = { var value : Nat = 1 };
  let nextAuditId = { var value : Nat = 1 };
  let nextChatId = { var value : Nat = 1 };
  let _nextABTestId = { var value : Nat = 1 };

  // ── Streaming state ────────────────────────────────────────────────────────
  let isStreamingActive = { var value : Bool = false };
  let streamingCount = { var value : Nat = 0 };
  let streamingLastAt = { var value : ?CommonTypes.Timestamp = null };

  // ── Timestamp of last rule computation (for decay alert) ──────────────────
  let nextRuleComputedAt = { var value : CommonTypes.Timestamp = 0 };

  // ── Core data collections ──────────────────────────────────────────────────
  let datasets = List.empty<TxTypes.TransactionDataset>();
  let transactions = Map.empty<CommonTypes.DatasetId, List.List<TxTypes.Transaction>>();
  let rules = List.empty<AnalyticsTypes.AssociationRule>();
  let userRoles = Map.empty<CommonTypes.UserId, CommonTypes.UserRole>();

  // ── Alerts ─────────────────────────────────────────────────────────────────
  let alerts = List.empty<AlertTypes.Alert>();

  // ── Audit log ─────────────────────────────────────────────────────────────
  let auditLog = List.empty<AuditTypes.AuditEntry>();

  // ── Chat history ──────────────────────────────────────────────────────────
  let chatHistory = List.empty<ChatTypes.ChatMessage>();

  // ── System settings (default values) ──────────────────────────────────────
  let systemSettings = {
    var value : SettingsTypes.SystemSettings = {
      pollingIntervalSecs = 30;
      alertThresholdLowSales = 0.1;
      alertThresholdTrending = 0.3;
      nlpServiceEndpoint = "";
      abTestDurationDays = 7;
      inventoryWarningLevel = 10;
      streamingAutoGenerateRate = 5;
    };
  };

  // ── Inventory ──────────────────────────────────────────────────────────────
  let inventoryItems = List.empty<InventoryTypes.InventoryItem>();

  // ── A/B testing ───────────────────────────────────────────────────────────
  let _abTests = List.empty<ABTestingTypes.ABTest>();
  let _abTestResults = List.empty<ABTestingTypes.ABTestResult>();

  // ── Seed sample grocery data ───────────────────────────────────────────────
  TransactionsLib.seedSampleData(datasets, transactions, nextDatasetId, Principal.anonymous());

  // ── Seed inventory for all products in sample dataset ─────────────────────
  let now = Time.now();
  let seedInventory : [(Text, Nat, Nat)] = [
    // (productName, stockLevel, reorderPoint)
    ("Milk", 150, 30),
    ("Bread", 200, 40),
    ("Eggs", 180, 36),
    ("Butter", 90, 20),
    ("Cheese", 75, 15),
    ("Yogurt", 60, 15),
    ("Coffee", 120, 25),
    ("Tea", 100, 20),
    ("Sugar", 140, 30),
    ("Flour", 110, 25),
    ("Pasta", 130, 30),
    ("Tomato Sauce", 95, 20),
    ("Beef", 55, 15),
    ("Chicken", 70, 20),
    ("Salmon", 40, 12),
    ("Rice", 160, 35),
    ("Olive Oil", 65, 15),
    ("Garlic", 80, 20),
    ("Onions", 90, 20),
    ("Potatoes", 120, 25),
    ("Carrots", 85, 20),
    ("Lettuce", 45, 12),
    ("Tomatoes", 70, 18),
    ("Apples", 95, 20),
    ("Bananas", 110, 25),
    ("Oranges", 85, 20),
    ("Grapes", 50, 12),
    ("Honey", 35, 8),
    ("Chocolate", 60, 15),
    ("Cookies", 75, 18),
    ("Chips", 80, 20),
    ("Beer", 90, 20),
    ("Wine", 55, 12),
    ("Soda", 100, 22),
    ("Cream", 40, 10),
    ("Bacon", 45, 12),
    ("Cereal", 65, 15),
    ("Orange Juice", 70, 18),
    ("Lemon", 55, 12),
    ("Soy Sauce", 45, 10),
    ("Crackers", 55, 12),
    ("Vegetables", 65, 15),
    ("Jam", 40, 10),
  ];
  for ((productName, stockLevel, reorderPoint) in seedInventory.values()) {
    inventoryItems.add({
      productId = productName;
      productName = productName;
      stockLevel = stockLevel;
      reorderPoint = reorderPoint;
      isInStock = stockLevel > 0;
      lastUpdated = now;
    });
  };

  // ── Seed 3 demo alerts (one per severity) ─────────────────────────────────
  alerts.add({
    id = nextAlertId.value;
    alertType = #newInsight;
    severity = #info;
    title = "Welcome to BasketIQ";
    message = "Your sample grocery dataset has been loaded. Click 'Compute Rules' on the Analytics page to discover product associations.";
    productId = null;
    metricValue = null;
    threshold = null;
    createdAt = now;
    isRead = false;
    isDismissed = false;
  });
  nextAlertId.value += 1;

  alerts.add({
    id = nextAlertId.value;
    alertType = #lowSales;
    severity = #warning;
    title = "Low Sales Alert: Cream";
    message = "Cream has appeared in few transactions with low confidence. Consider a promotional bundle with Coffee or Butter.";
    productId = ?"Cream";
    metricValue = ?0.08;
    threshold = ?0.3;
    createdAt = now;
    isRead = false;
    isDismissed = false;
  });
  nextAlertId.value += 1;

  alerts.add({
    id = nextAlertId.value;
    alertType = #inventoryWarning;
    severity = #critical;
    title = "Critical Stock: Honey";
    message = "Honey stock level (35) is approaching reorder point (8). Monitor closely and consider restocking if demand spikes.";
    productId = ?"Honey";
    metricValue = ?35.0;
    threshold = ?8.0;
    createdAt = now;
    isRead = false;
    isDismissed = false;
  });
  nextAlertId.value += 1;

  // ── Mixin includes ─────────────────────────────────────────────────────────
  include TransactionsMixin(accessControlState, datasets, transactions, nextDatasetId);
  include AnalyticsMixin(accessControlState, datasets, transactions, rules, nextRuleId);
  include UsersMixin(accessControlState, userRoles);
  include AlertsMixin(
    accessControlState,
    alerts,
    rules,
    inventoryItems,
    nextAlertId,
    nextRuleComputedAt,
    auditLog,
    nextAuditId,
  );
  include AuditMixin(accessControlState, auditLog, nextAuditId);
  include ChatbotMixin(
    accessControlState,
    chatHistory,
    nextChatId,
    rules,
    systemSettings,
    auditLog,
    nextAuditId,
  );
  include AdminMixin(
    accessControlState,
    userRoles,
    systemSettings,
    inventoryItems,
    datasets,
    transactions,
    nextDatasetId,
    isStreamingActive,
    streamingCount,
    streamingLastAt,
    auditLog,
    nextAuditId,
  );
};
