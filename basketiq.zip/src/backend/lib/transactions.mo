import List "mo:core/List";
import Map "mo:core/Map";
import Set "mo:core/Set";
import Time "mo:core/Time";
import Principal "mo:core/Principal";
import CommonTypes "../types/common";
import TxTypes "../types/transactions";

module {
  public func createDataset(
    datasets : List.List<TxTypes.TransactionDataset>,
    transactions : Map.Map<CommonTypes.DatasetId, List.List<TxTypes.Transaction>>,
    nextId : Nat,
    caller : Principal,
    name : Text,
    products : [[Text]],
  ) : Nat {
    let datasetId = nextId;
    let now = Time.now();

    let txList = List.empty<TxTypes.Transaction>();
    var txId : Nat = 1;
    for (productSet in products.values()) {
      txList.add({
        id = txId;
        products = productSet;
        timestamp = now;
        uploadedBy = caller;
      });
      txId += 1;
    };

    datasets.add({
      id = datasetId;
      name = name;
      recordCount = txList.size();
      uploadTimestamp = now;
      uploadedBy = caller;
    });

    transactions.add(datasetId, txList);
    datasetId;
  };

  public func getDatasets(
    datasets : List.List<TxTypes.TransactionDataset>
  ) : [TxTypes.TransactionDataset] {
    datasets.toArray();
  };

  public func getDatasetTransactions(
    transactions : Map.Map<CommonTypes.DatasetId, List.List<TxTypes.Transaction>>,
    datasetId : CommonTypes.DatasetId,
  ) : [TxTypes.Transaction] {
    switch (transactions.get(datasetId)) {
      case (?txList) { txList.toArray() };
      case null { [] };
    };
  };

  public func datasetExists(
    datasets : List.List<TxTypes.TransactionDataset>,
    datasetId : CommonTypes.DatasetId,
  ) : Bool {
    switch (datasets.find(func(d : TxTypes.TransactionDataset) : Bool { d.id == datasetId })) {
      case (?_) { true };
      case null { false };
    };
  };

  public func totalTransactionCount(
    transactions : Map.Map<CommonTypes.DatasetId, List.List<TxTypes.Transaction>>
  ) : Nat {
    var total : Nat = 0;
    for ((_, txList) in transactions.entries()) {
      total += txList.size();
    };
    total;
  };

  public func getAllProducts(
    transactions : Map.Map<CommonTypes.DatasetId, List.List<TxTypes.Transaction>>
  ) : [Text] {
    let productSet = Set.empty<Text>();
    for ((_, txList) in transactions.entries()) {
      txList.forEach(func(tx : TxTypes.Transaction) {
        for (p in tx.products.values()) {
          productSet.add(p);
        };
      });
    };
    productSet.toArray();
  };

  public func seedSampleData(
    datasets : List.List<TxTypes.TransactionDataset>,
    transactions : Map.Map<CommonTypes.DatasetId, List.List<TxTypes.Transaction>>,
    nextIdRef : { var value : Nat },
    systemPrincipal : Principal,
  ) : () {
    // 200+ realistic grocery transactions with common purchase patterns
    let sampleTransactions : [[Text]] = [
      // Milk + Bread + Eggs cluster (very frequent)
      ["Milk", "Bread", "Eggs"],
      ["Milk", "Bread", "Eggs", "Butter"],
      ["Milk", "Bread"],
      ["Milk", "Eggs", "Butter"],
      ["Bread", "Eggs", "Butter"],
      ["Milk", "Bread", "Eggs", "Cheese"],
      ["Milk", "Bread", "Butter"],
      ["Bread", "Butter", "Eggs"],
      ["Milk", "Cheese", "Eggs"],
      ["Milk", "Bread", "Eggs", "Yogurt"],
      ["Milk", "Eggs"],
      ["Bread", "Milk"],
      ["Eggs", "Butter", "Milk"],
      ["Milk", "Bread", "Eggs", "Butter", "Cheese"],
      ["Milk", "Yogurt", "Bread"],

      // Coffee + Sugar + Milk cluster
      ["Coffee", "Sugar", "Milk"],
      ["Coffee", "Sugar"],
      ["Coffee", "Milk", "Sugar", "Tea"],
      ["Coffee", "Sugar", "Bread"],
      ["Coffee", "Milk"],
      ["Tea", "Sugar", "Milk"],
      ["Coffee", "Tea", "Sugar"],
      ["Coffee", "Sugar", "Milk", "Cookies"],
      ["Tea", "Sugar"],
      ["Coffee", "Milk", "Sugar", "Bread"],
      ["Coffee", "Sugar", "Milk", "Butter"],
      ["Tea", "Milk", "Sugar", "Cookies"],
      ["Coffee", "Sugar", "Cream"],
      ["Coffee", "Milk", "Bread"],
      ["Tea", "Sugar", "Milk", "Lemon"],

      // Pasta + Tomato Sauce + Beef cluster
      ["Pasta", "Tomato Sauce", "Beef"],
      ["Pasta", "Tomato Sauce"],
      ["Pasta", "Tomato Sauce", "Beef", "Onions"],
      ["Pasta", "Beef", "Garlic"],
      ["Pasta", "Tomato Sauce", "Chicken"],
      ["Pasta", "Olive Oil", "Garlic"],
      ["Pasta", "Tomato Sauce", "Beef", "Garlic", "Onions"],
      ["Tomato Sauce", "Beef", "Onions", "Garlic"],
      ["Pasta", "Tomato Sauce", "Olive Oil"],
      ["Pasta", "Beef", "Onions"],
      ["Pasta", "Tomato Sauce", "Salmon"],
      ["Pasta", "Garlic", "Olive Oil", "Tomatoes"],
      ["Pasta", "Chicken", "Tomatoes"],
      ["Pasta", "Tomato Sauce", "Cheese"],
      ["Pasta", "Olive Oil", "Garlic", "Tomatoes"],

      // Chicken + Vegetables cluster
      ["Chicken", "Potatoes", "Carrots"],
      ["Chicken", "Onions", "Garlic"],
      ["Chicken", "Lettuce", "Tomatoes"],
      ["Chicken", "Rice", "Onions"],
      ["Chicken", "Garlic", "Olive Oil"],
      ["Chicken", "Potatoes", "Onions", "Carrots"],
      ["Chicken", "Tomatoes", "Lettuce", "Onions"],
      ["Chicken", "Rice", "Garlic"],
      ["Chicken", "Pasta", "Garlic"],
      ["Chicken", "Lettuce", "Tomatoes", "Onions"],

      // Salmon + Vegetables cluster
      ["Salmon", "Lettuce", "Tomatoes"],
      ["Salmon", "Olive Oil", "Garlic"],
      ["Salmon", "Potatoes", "Onions"],
      ["Salmon", "Rice", "Garlic"],
      ["Salmon", "Lemon", "Olive Oil"],
      ["Salmon", "Lettuce", "Onions"],
      ["Salmon", "Olive Oil", "Garlic", "Lemon"],

      // Beef cluster
      ["Beef", "Onions", "Garlic", "Potatoes"],
      ["Beef", "Tomatoes", "Onions"],
      ["Beef", "Rice", "Onions"],
      ["Beef", "Potatoes", "Carrots", "Onions"],
      ["Beef", "Garlic", "Onions"],

      // Fruit cluster
      ["Apples", "Bananas", "Oranges"],
      ["Apples", "Bananas"],
      ["Apples", "Oranges"],
      ["Bananas", "Yogurt"],
      ["Apples", "Yogurt"],
      ["Oranges", "Apples", "Bananas", "Yogurt"],
      ["Apples", "Bananas", "Orange Juice"],
      ["Oranges", "Bananas"],
      ["Apples", "Oranges", "Yogurt"],
      ["Bananas", "Orange Juice"],

      // Breakfast cluster
      ["Milk", "Cereal", "Bananas"],
      ["Eggs", "Bacon", "Bread", "Butter"],
      ["Yogurt", "Bananas", "Honey"],
      ["Milk", "Coffee", "Bread", "Butter"],
      ["Eggs", "Milk", "Bread", "Orange Juice"],
      ["Yogurt", "Apples", "Honey"],
      ["Cereal", "Milk", "Orange Juice"],
      ["Bread", "Butter", "Coffee"],
      ["Eggs", "Bacon", "Coffee"],
      ["Milk", "Bread", "Orange Juice"],

      // Snack cluster
      ["Chips", "Beer"],
      ["Chips", "Cookies"],
      ["Chocolate", "Cookies"],
      ["Chips", "Chocolate", "Cookies"],
      ["Beer", "Chips", "Soda"],
      ["Wine", "Cheese", "Crackers"],
      ["Beer", "Chips"],
      ["Chocolate", "Milk"],
      ["Cookies", "Milk", "Tea"],
      ["Wine", "Cheese"],

      // Wine + Cheese cluster
      ["Wine", "Cheese", "Bread"],
      ["Wine", "Grapes", "Cheese"],
      ["Wine", "Salmon", "Lemon"],
      ["Wine", "Olive Oil", "Tomatoes"],
      ["Wine", "Cheese", "Crackers", "Grapes"],
      ["Beer", "Chicken", "Onions"],
      ["Beer", "Beef", "Chips"],
      ["Wine", "Pasta", "Tomato Sauce"],

      // Rice + Asian cooking cluster
      ["Rice", "Chicken", "Soy Sauce"],
      ["Rice", "Salmon", "Soy Sauce"],
      ["Rice", "Vegetables", "Garlic"],
      ["Rice", "Beef", "Onions"],
      ["Rice", "Eggs", "Soy Sauce"],
      ["Rice", "Garlic", "Onions"],

      // General mixed transactions
      ["Flour", "Sugar", "Butter", "Eggs"],
      ["Flour", "Milk", "Eggs", "Butter"],
      ["Flour", "Sugar", "Milk"],
      ["Flour", "Butter", "Sugar", "Eggs", "Chocolate"],
      ["Flour", "Eggs", "Sugar"],
      ["Sugar", "Butter", "Eggs", "Flour"],
      ["Flour", "Milk", "Butter"],

      // Large shopping trips
      ["Milk", "Bread", "Eggs", "Butter", "Cheese", "Yogurt", "Apples", "Bananas"],
      ["Chicken", "Beef", "Onions", "Garlic", "Potatoes", "Carrots", "Tomatoes"],
      ["Pasta", "Tomato Sauce", "Beef", "Onions", "Garlic", "Olive Oil", "Wine"],
      ["Coffee", "Tea", "Sugar", "Milk", "Cookies", "Chocolate"],
      ["Rice", "Chicken", "Garlic", "Onions", "Tomatoes", "Olive Oil"],
      ["Salmon", "Lettuce", "Tomatoes", "Onions", "Olive Oil", "Lemon"],
      ["Milk", "Yogurt", "Cheese", "Butter", "Eggs", "Bread", "Coffee"],
      ["Apples", "Oranges", "Bananas", "Yogurt", "Milk", "Honey"],
      ["Beer", "Chips", "Chocolate", "Cookies", "Soda"],
      ["Wine", "Cheese", "Bread", "Grapes", "Crackers", "Olive Oil"],

      // Repeat common patterns for frequency weighting
      ["Milk", "Bread", "Eggs"],
      ["Coffee", "Sugar", "Milk"],
      ["Pasta", "Tomato Sauce", "Beef"],
      ["Chicken", "Onions", "Garlic"],
      ["Apples", "Bananas", "Oranges"],
      ["Milk", "Bread", "Eggs", "Butter"],
      ["Coffee", "Sugar"],
      ["Pasta", "Tomato Sauce"],
      ["Chicken", "Rice", "Onions"],
      ["Wine", "Cheese"],

      ["Milk", "Bread"],
      ["Eggs", "Butter"],
      ["Coffee", "Milk", "Sugar"],
      ["Pasta", "Beef", "Garlic"],
      ["Salmon", "Olive Oil"],
      ["Apples", "Yogurt"],
      ["Chips", "Beer"],
      ["Bread", "Butter", "Milk"],
      ["Tea", "Sugar"],
      ["Rice", "Chicken", "Garlic"],

      ["Milk", "Eggs", "Cheese"],
      ["Coffee", "Sugar", "Cookies"],
      ["Pasta", "Garlic", "Olive Oil"],
      ["Chicken", "Lettuce", "Tomatoes"],
      ["Oranges", "Apples"],
      ["Yogurt", "Bananas"],
      ["Wine", "Grapes"],
      ["Beef", "Onions", "Garlic"],
      ["Flour", "Eggs", "Butter"],
      ["Chocolate", "Milk"],

      ["Bread", "Eggs", "Milk"],
      ["Sugar", "Coffee", "Milk"],
      ["Tomato Sauce", "Pasta"],
      ["Garlic", "Chicken", "Olive Oil"],
      ["Bananas", "Apples", "Orange Juice"],
      ["Cheese", "Wine", "Crackers"],
      ["Chips", "Soda"],
      ["Butter", "Bread"],
      ["Onions", "Garlic", "Tomatoes"],
      ["Rice", "Beef", "Garlic"],

      ["Milk", "Coffee", "Sugar"],
      ["Bread", "Cheese", "Butter"],
      ["Pasta", "Olive Oil", "Tomatoes"],
      ["Beef", "Potatoes", "Carrots"],
      ["Eggs", "Milk", "Butter"],
      ["Apples", "Oranges", "Yogurt"],
      ["Beer", "Chicken", "Chips"],
      ["Wine", "Salmon", "Lemon"],
      ["Tea", "Milk", "Honey"],
      ["Flour", "Sugar", "Butter"],
    ];

    let now = Time.now();
    let datasetId = nextIdRef.value;
    nextIdRef.value += 1;

    let txList = List.empty<TxTypes.Transaction>();
    var txId : Nat = 1;
    for (productSet in sampleTransactions.values()) {
      txList.add({
        id = txId;
        products = productSet;
        timestamp = now;
        uploadedBy = systemPrincipal;
      });
      txId += 1;
    };

    datasets.add({
      id = datasetId;
      name = "Sample Grocery Transactions";
      recordCount = txList.size();
      uploadTimestamp = now;
      uploadedBy = systemPrincipal;
    });

    transactions.add(datasetId, txList);
  };
};
