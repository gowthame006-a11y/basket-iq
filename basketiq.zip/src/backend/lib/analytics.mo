import List "mo:core/List";
import Map "mo:core/Map";
import Array "mo:core/Array";
import Iter "mo:core/Iter";
import Text "mo:core/Text";
import CommonTypes "../types/common";
import TxTypes "../types/transactions";
import AnalyticsTypes "../types/analytics";

module {
  // Canonical pair key: sorted so (A,B) and (B,A) map to same key
  func pairKey(a : Text, b : Text) : Text {
    if (a <= b) { a # "\u{0000}" # b } else { b # "\u{0000}" # a };
  };

  // Split a pair key back into two items
  func splitPairKey(key : Text) : ?(Text, Text) {
    let parts = key.split(#char '\u{0000}').toArray();
    if (parts.size() == 2) {
      ?(parts[0], parts[1])
    } else {
      null
    };
  };

  public func computeRules(
    transactions : [TxTypes.Transaction],
    datasetId : CommonTypes.DatasetId,
    minSupport : Float,
    minConfidence : Float,
    startingRuleId : Nat,
  ) : [AnalyticsTypes.AssociationRule] {
    let totalTx = transactions.size();
    if (totalTx == 0) { return [] };

    let totalFloat : Float = totalTx.toFloat();

    // Count individual item frequencies
    let itemFreq = Map.empty<Text, Nat>();
    for (tx in transactions.values()) {
      for (p in tx.products.values()) {
        let current = switch (itemFreq.get(p)) {
          case (?n) { n };
          case null { 0 };
        };
        itemFreq.add(p, current + 1);
      };
    };

    // Count pair co-occurrences
    let pairFreq = Map.empty<Text, Nat>();
    for (tx in transactions.values()) {
      let products = tx.products;
      let n = products.size();
      var i = 0;
      while (i < n) {
        var j = i + 1;
        while (j < n) {
          let key = pairKey(products[i], products[j]);
          let current = switch (pairFreq.get(key)) {
            case (?c) { c };
            case null { 0 };
          };
          pairFreq.add(key, current + 1);
          j += 1;
        };
        i += 1;
      };
    };

    // Generate rules from pairs
    let rules = List.empty<AnalyticsTypes.AssociationRule>();
    var ruleId = startingRuleId;

    for ((key, pairCount) in pairFreq.entries()) {
      let support : Float = pairCount.toFloat() / totalFloat;
      if (support >= minSupport) {
        switch (splitPairKey(key)) {
          case null { /* skip */ };
          case (?(itemA, itemB)) {
            let countA = switch (itemFreq.get(itemA)) { case (?n) n; case null 0 };
            let countB = switch (itemFreq.get(itemB)) { case (?n) n; case null 0 };

            // Rule A -> B
            if (countA > 0) {
              let confAB : Float = pairCount.toFloat() / countA.toFloat();
              if (confAB >= minConfidence) {
                let liftAB : Float = confAB / (countB.toFloat() / totalFloat);
                rules.add({
                  id = ruleId;
                  datasetId = datasetId;
                  antecedent = itemA;
                  consequent = itemB;
                  support = support;
                  confidence = confAB;
                  lift = liftAB;
                });
                ruleId += 1;
              };
            };

            // Rule B -> A
            if (countB > 0) {
              let confBA : Float = pairCount.toFloat() / countB.toFloat();
              if (confBA >= minConfidence) {
                let liftBA : Float = confBA / (countA.toFloat() / totalFloat);
                rules.add({
                  id = ruleId;
                  datasetId = datasetId;
                  antecedent = itemB;
                  consequent = itemA;
                  support = support;
                  confidence = confBA;
                  lift = liftBA;
                });
                ruleId += 1;
              };
            };
          };
        };
      };
    };

    rules.toArray();
  };

  public func getRulesForDataset(
    rules : List.List<AnalyticsTypes.AssociationRule>,
    datasetId : CommonTypes.DatasetId,
  ) : [AnalyticsTypes.AssociationRule] {
    rules.filter(func(r : AnalyticsTypes.AssociationRule) : Bool {
      r.datasetId == datasetId
    }).toArray();
  };

  public func getRecommendations(
    rules : List.List<AnalyticsTypes.AssociationRule>,
    productName : Text,
    topN : Nat,
  ) : [AnalyticsTypes.Recommendation] {
    let matching = rules.filter(func(r : AnalyticsTypes.AssociationRule) : Bool {
      r.antecedent == productName
    });

    let sorted = matching.sort(
      func(a : AnalyticsTypes.AssociationRule, b : AnalyticsTypes.AssociationRule) : {#less; #equal; #greater} {
        if (a.lift > b.lift) { #less }
        else if (a.lift < b.lift) { #greater }
        else { #equal };
      }
    );

    let recs = sorted.map<AnalyticsTypes.AssociationRule, AnalyticsTypes.Recommendation>(func(r) {
      {
        product = r.consequent;
        lift = r.lift;
        confidence = r.confidence;
        support = r.support;
      }
    });

    let sz = recs.size();
    if (topN == 0 or sz <= topN) {
      recs.toArray()
    } else {
      recs.sliceToArray(0, topN)
    };
  };

  public func getTopProductPairs(
    transactions : Map.Map<CommonTypes.DatasetId, List.List<TxTypes.Transaction>>,
    limit : Nat,
  ) : [AnalyticsTypes.ProductPair] {
    var totalTx : Nat = 0;
    for ((_, txList) in transactions.entries()) {
      totalTx += txList.size();
    };
    if (totalTx == 0) { return [] };
    let totalFloat : Float = totalTx.toFloat();

    // Count pair co-occurrences across all datasets
    let pairFreq = Map.empty<Text, Nat>();
    for ((_, txList) in transactions.entries()) {
      txList.forEach(func(tx : TxTypes.Transaction) {
        let products = tx.products;
        let n = products.size();
        var i = 0;
        while (i < n) {
          var j = i + 1;
          while (j < n) {
            let key = pairKey(products[i], products[j]);
            let current = switch (pairFreq.get(key)) {
              case (?c) { c };
              case null { 0 };
            };
            pairFreq.add(key, current + 1);
            j += 1;
          };
          i += 1;
        };
      });
    };

    // Convert to ProductPair list
    let pairs = List.empty<AnalyticsTypes.ProductPair>();
    for ((key, count) in pairFreq.entries()) {
      switch (splitPairKey(key)) {
        case null {};
        case (?(itemA, itemB)) {
          pairs.add({
            productA = itemA;
            productB = itemB;
            coOccurrences = count;
            support = count.toFloat() / totalFloat;
          });
        };
      };
    };

    // Sort by support descending
    let sorted = pairs.sort(
      func(a : AnalyticsTypes.ProductPair, b : AnalyticsTypes.ProductPair) : {#less; #equal; #greater} {
        if (a.support > b.support) { #less }
        else if (a.support < b.support) { #greater }
        else { #equal };
      }
    );

    let sz = sorted.size();
    if (limit == 0 or sz <= limit) {
      sorted.toArray()
    } else {
      sorted.sliceToArray(0, limit)
    };
  };

  public func computeDashboardStats(
    datasets : List.List<TxTypes.TransactionDataset>,
    transactions : Map.Map<CommonTypes.DatasetId, List.List<TxTypes.Transaction>>,
    rules : List.List<AnalyticsTypes.AssociationRule>,
  ) : AnalyticsTypes.DashboardStats {
    let totalDatasets = datasets.size();

    var totalTransactions : Nat = 0;
    for ((_, txList) in transactions.entries()) {
      totalTransactions += txList.size();
    };

    let totalRules = rules.size();

    // Count unique products and their frequencies
    let productFreq = Map.empty<Text, Nat>();
    for ((_, txList) in transactions.entries()) {
      txList.forEach(func(tx : TxTypes.Transaction) {
        for (p in tx.products.values()) {
          let current = switch (productFreq.get(p)) {
            case (?n) { n };
            case null { 0 };
          };
          productFreq.add(p, current + 1);
        };
      });
    };
    let totalProducts = productFreq.size();

    // Average lift
    let avgLift : Float = if (totalRules == 0) {
      0.0
    } else {
      let sumLift = rules.foldLeft(0.0, func(acc : Float, r : AnalyticsTypes.AssociationRule) : Float {
        acc + r.lift
      });
      sumLift / totalRules.toFloat()
    };

    // Top 10 products by frequency
    let freqList = List.empty<(Text, Nat)>();
    for ((product, freq) in productFreq.entries()) {
      freqList.add((product, freq));
    };
    let sortedFreq = freqList.sort(
      func(a : (Text, Nat), b : (Text, Nat)) : {#less; #equal; #greater} {
        if (a.1 > b.1) { #less }
        else if (a.1 < b.1) { #greater }
        else { #equal };
      }
    );
    let top10 = if (sortedFreq.size() < 10) sortedFreq.size() else 10;
    let topArr = sortedFreq.sliceToArray(0, top10);
    let topProducts = topArr.map(func(pair : (Text, Nat)) : Text { pair.0 });

    {
      totalDatasets = totalDatasets;
      totalTransactions = totalTransactions;
      totalRules = totalRules;
      totalProducts = totalProducts;
      avgLift = avgLift;
      topProducts = topProducts;
    };
  };
};
