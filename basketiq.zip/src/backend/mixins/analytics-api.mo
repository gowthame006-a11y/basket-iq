import List "mo:core/List";
import Map "mo:core/Map";
import Runtime "mo:core/Runtime";
import AccessControl "mo:caffeineai-authorization/access-control";
import CommonTypes "../types/common";
import TxTypes "../types/transactions";
import AnalyticsTypes "../types/analytics";
import AnalyticsLib "../lib/analytics";
import TransactionsLib "../lib/transactions";

mixin (
  accessControlState : AccessControl.AccessControlState,
  datasets : List.List<TxTypes.TransactionDataset>,
  transactions : Map.Map<CommonTypes.DatasetId, List.List<TxTypes.Transaction>>,
  rules : List.List<AnalyticsTypes.AssociationRule>,
  nextRuleId : { var value : Nat },
) {
  public shared ({ caller }) func computeAssociationRules(
    datasetId : CommonTypes.DatasetId,
    minSupport : Float,
    minConfidence : Float,
  ) : async Nat {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Must be logged in to compute rules");
    };
    if (not TransactionsLib.datasetExists(datasets, datasetId)) {
      Runtime.trap("Dataset not found");
    };
    let txArray = TransactionsLib.getDatasetTransactions(transactions, datasetId);
    let newRules = AnalyticsLib.computeRules(txArray, datasetId, minSupport, minConfidence, nextRuleId.value);

    // Remove existing rules for this dataset, then add new ones
    let kept = rules.filter(func(r : AnalyticsTypes.AssociationRule) : Bool { r.datasetId != datasetId });
    rules.clear();
    rules.append(kept);

    for (r in newRules.values()) {
      rules.add(r);
    };

    nextRuleId.value += newRules.size();
    newRules.size();
  };

  public query func getAssociationRules(
    datasetId : CommonTypes.DatasetId
  ) : async [AnalyticsTypes.AssociationRule] {
    AnalyticsLib.getRulesForDataset(rules, datasetId);
  };

  public query func getRecommendations(
    productName : Text,
    topN : Nat,
  ) : async [AnalyticsTypes.Recommendation] {
    AnalyticsLib.getRecommendations(rules, productName, topN);
  };

  public query func getTopProductPairs(limit : Nat) : async [AnalyticsTypes.ProductPair] {
    AnalyticsLib.getTopProductPairs(transactions, limit);
  };

  public query func getDashboardStats() : async AnalyticsTypes.DashboardStats {
    AnalyticsLib.computeDashboardStats(datasets, transactions, rules);
  };
};
