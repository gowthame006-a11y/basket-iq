import List "mo:core/List";
import Map "mo:core/Map";
import Runtime "mo:core/Runtime";
import AccessControl "mo:caffeineai-authorization/access-control";
import CommonTypes "../types/common";
import TxTypes "../types/transactions";
import TransactionsLib "../lib/transactions";

mixin (
  accessControlState : AccessControl.AccessControlState,
  datasets : List.List<TxTypes.TransactionDataset>,
  transactions : Map.Map<CommonTypes.DatasetId, List.List<TxTypes.Transaction>>,
  nextDatasetId : { var value : Nat },
) {
  public query func getTransactionDatasets() : async [TxTypes.TransactionDataset] {
    TransactionsLib.getDatasets(datasets);
  };

  public shared ({ caller }) func addTransactionDataset(
    name : Text,
    products : [[Text]],
  ) : async CommonTypes.DatasetId {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Must be logged in to add datasets");
    };
    let id = nextDatasetId.value;
    nextDatasetId.value += 1;
    let _ = TransactionsLib.createDataset(datasets, transactions, id, caller, name, products);
    id;
  };
};
