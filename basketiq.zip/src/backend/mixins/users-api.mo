import Map "mo:core/Map";
import Principal "mo:core/Principal";
import Runtime "mo:core/Runtime";
import AccessControl "mo:caffeineai-authorization/access-control";
import CommonTypes "../types/common";

mixin (
  accessControlState : AccessControl.AccessControlState,
  userRoles : Map.Map<CommonTypes.UserId, CommonTypes.UserRole>,
) {
  public query ({ caller }) func getUserRole() : async Text {
    let acRole = AccessControl.getUserRole(accessControlState, caller);
    switch (acRole) {
      case (#admin) { "admin" };
      case (#user) {
        // Check our custom role map for analyst vs generic user
        switch (userRoles.get(caller)) {
          case (?(#analyst)) { "analyst" };
          case (_) { "analyst" };
        };
      };
      case (#guest) { "guest" };
    };
  };

  public shared ({ caller }) func setUserRole(
    userId : CommonTypes.UserId,
    role : Text,
  ) : async Bool {
    if (not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Only admins can set user roles");
    };
    switch (role) {
      case ("admin") {
        AccessControl.assignRole(accessControlState, caller, userId, #admin);
        userRoles.add(userId, #admin);
      };
      case ("analyst") {
        AccessControl.assignRole(accessControlState, caller, userId, #user);
        userRoles.add(userId, #analyst);
      };
      case (_) { Runtime.trap("Invalid role. Use 'admin' or 'analyst'") };
    };
    true;
  };
};
