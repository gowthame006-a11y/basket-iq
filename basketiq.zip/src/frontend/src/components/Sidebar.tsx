import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  BarChart2,
  Database,
  GitBranch,
  LayoutDashboard,
  LogOut,
  MessageSquare,
  Settings,
  Shield,
  ShoppingCart,
  Shuffle,
  TrendingUp,
} from "lucide-react";
import { useAuth } from "../hooks/useAuth";
import { useAlertStats } from "../hooks/useBackend";

interface NavItem {
  label: string;
  path: string;
  icon: React.ComponentType<{ className?: string }>;
  adminOnly?: boolean;
  showAlertBadge?: boolean;
}

const NAV_ITEMS: NavItem[] = [
  {
    label: "Dashboard",
    path: "/dashboard",
    icon: LayoutDashboard,
    showAlertBadge: true,
  },
  { label: "Association Rules", path: "/rules", icon: Shuffle },
  { label: "Recommendations", path: "/recommendations", icon: BarChart2 },
  { label: "Analytics Insights", path: "/analytics", icon: TrendingUp },
  { label: "Network Graph", path: "/network-graph", icon: GitBranch },
  { label: "Chatbot", path: "/chatbot", icon: MessageSquare },
  { label: "Data Upload", path: "/upload", icon: Database, adminOnly: true },
  { label: "Admin Panel", path: "/admin", icon: Shield, adminOnly: true },
  { label: "Settings", path: "/settings", icon: Settings },
];

export function Sidebar() {
  const { userRole, isAdmin, logout, principal } = useAuth();
  const routerState = useRouterState();
  const currentPath = routerState.location.pathname;
  const { data: alertStats } = useAlertStats();

  const visibleItems = NAV_ITEMS.filter((item) => !item.adminOnly || isAdmin);

  const shortPrincipal = principal
    ? `${principal.slice(0, 5)}...${principal.slice(-3)}`
    : "—";

  const criticalCount = alertStats?.critical ?? 0;

  return (
    <aside
      className="flex h-screen w-60 flex-col border-r border-border bg-sidebar"
      data-ocid="sidebar"
    >
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-5 py-5">
        <div className="flex h-8 w-8 items-center justify-center rounded-md bg-accent/20">
          <ShoppingCart className="h-4 w-4 text-accent" />
        </div>
        <div>
          <div className="font-display text-sm font-semibold text-sidebar-foreground leading-none">
            BasketIQ
          </div>
          <div className="text-[10px] text-muted-foreground mt-0.5 font-body">
            Market Basket Analysis
          </div>
        </div>
      </div>

      <Separator className="bg-sidebar-border" />

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-0.5">
        {visibleItems.map((item) => {
          const Icon = item.icon;
          const isActive =
            currentPath === item.path ||
            (item.path !== "/" && currentPath.startsWith(item.path));

          return (
            <Link
              key={item.path}
              to={item.path}
              data-ocid={`sidebar.nav.${item.label.toLowerCase().replace(/\s+/g, "_")}`}
              className={`flex items-center gap-3 rounded-md px-3 py-2 text-sm font-body transition-smooth ${
                isActive
                  ? "bg-accent/15 text-accent font-medium"
                  : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              }`}
            >
              <Icon
                className={`h-4 w-4 flex-shrink-0 ${isActive ? "text-accent" : ""}`}
              />
              <span className="flex-1 truncate">{item.label}</span>
              {item.showAlertBadge && criticalCount > 0 && (
                <span
                  className="flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-semibold text-destructive-foreground"
                  data-ocid="sidebar.critical_alert_badge"
                >
                  {criticalCount > 99 ? "99+" : criticalCount}
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      <Separator className="bg-sidebar-border" />

      {/* User info + logout */}
      <div className="px-4 py-4 space-y-3">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary/20 text-xs font-semibold text-primary font-body">
            {userRole === "admin" ? "AD" : userRole === "analyst" ? "AN" : "VW"}
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-xs text-sidebar-foreground truncate font-body">
              {shortPrincipal}
            </div>
            <Badge
              variant={userRole === "admin" ? "default" : "secondary"}
              className={`mt-0.5 text-[10px] h-4 px-1.5 ${
                userRole === "admin"
                  ? "bg-accent/20 text-accent border-accent/30"
                  : "bg-primary/20 text-primary border-primary/30"
              }`}
              data-ocid="sidebar.role_badge"
            >
              {userRole}
            </Badge>
          </div>
        </div>

        <Button
          variant="ghost"
          size="sm"
          className="w-full justify-start gap-2 text-muted-foreground hover:text-foreground hover:bg-sidebar-accent text-xs font-body"
          onClick={logout}
          data-ocid="sidebar.logout_button"
        >
          <LogOut className="h-3.5 w-3.5" />
          Sign out
        </Button>
      </div>
    </aside>
  );
}
