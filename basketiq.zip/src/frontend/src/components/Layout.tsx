import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import { type ReactNode, useState } from "react";
import {
  useAlerts,
  useDismissAlert,
  useMarkAlertRead,
} from "../hooks/useBackend";
import { Sidebar } from "./Sidebar";

interface LayoutProps {
  children: ReactNode;
  title?: string;
  actions?: ReactNode;
}

function AlertBar() {
  const { data: alerts } = useAlerts(false);
  const markRead = useMarkAlertRead();
  const dismiss = useDismissAlert();
  const [hidden, setHidden] = useState<Set<string>>(new Set());

  const criticalAlerts = (alerts ?? []).filter(
    (a) =>
      a.severity === "critical" &&
      !a.isDismissed &&
      !a.isRead &&
      !hidden.has(String(a.id)),
  );

  if (criticalAlerts.length === 0) return null;

  // Show only the first critical alert in the bar
  const alert = criticalAlerts[0];

  function handleDismiss() {
    dismiss.mutate(alert.id);
    setHidden((prev) => new Set([...prev, String(alert.id)]));
    markRead.mutate(alert.id);
  }

  return (
    <div
      className="flex items-center justify-between gap-3 border-b border-destructive/40 bg-destructive/10 px-6 py-2.5 flex-shrink-0"
      data-ocid="layout.alert_bar"
      role="alert"
      aria-live="polite"
    >
      <div className="flex items-center gap-2 min-w-0">
        <span className="h-2 w-2 flex-shrink-0 rounded-full bg-destructive animate-pulse" />
        <span className="text-xs font-semibold text-destructive font-body truncate">
          {alert.title}
        </span>
        <span className="text-xs text-muted-foreground font-body truncate hidden sm:block">
          — {alert.message}
        </span>
        {criticalAlerts.length > 1 && (
          <span className="text-[10px] text-muted-foreground font-body flex-shrink-0">
            +{criticalAlerts.length - 1} more
          </span>
        )}
      </div>
      <Button
        variant="ghost"
        size="icon"
        className="h-6 w-6 flex-shrink-0 text-muted-foreground hover:text-foreground"
        onClick={handleDismiss}
        aria-label="Dismiss alert"
        data-ocid="layout.alert_bar.close_button"
      >
        <X className="h-3.5 w-3.5" />
      </Button>
    </div>
  );
}

export function Layout({ children, title, actions }: LayoutProps) {
  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />

      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Global critical alerts bar */}
        <AlertBar />

        {/* Page header */}
        {(title || actions) && (
          <header className="flex items-center justify-between border-b border-border bg-card px-6 py-4 flex-shrink-0">
            {title && (
              <h1 className="font-display text-xl font-semibold text-foreground">
                {title}
              </h1>
            )}
            {actions && (
              <div className="flex items-center gap-2">{actions}</div>
            )}
          </header>
        )}

        {/* Scrollable content area */}
        <main className="flex-1 overflow-y-auto bg-background p-6">
          {children}
        </main>

        {/* Footer */}
        <footer className="flex-shrink-0 border-t border-border bg-muted/40 px-6 py-2.5">
          <p className="text-[11px] text-muted-foreground font-body text-center">
            © {new Date().getFullYear()}.{" "}
            <a
              href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(
                typeof window !== "undefined" ? window.location.hostname : "",
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-accent hover:underline"
            >
              Built with love using caffeine.ai
            </a>
          </p>
        </footer>
      </div>
    </div>
  );
}
