import { useActor } from "@caffeineai/core-infrastructure";
import { useInternetIdentity } from "@caffeineai/core-infrastructure";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { UserRole__1, createActor } from "../backend";
import type { AppUserRole } from "../types";

export function useAuth() {
  const {
    login,
    clear,
    isAuthenticated,
    isInitializing,
    isLoggingIn,
    identity,
  } = useInternetIdentity();
  const { actor, isFetching: actorFetching } = useActor(createActor);
  const queryClient = useQueryClient();

  const roleQuery = useQuery<UserRole__1>({
    queryKey: ["callerUserRole"],
    queryFn: async () => {
      if (!actor) throw new Error("Actor not available");
      return actor.getCallerUserRole();
    },
    enabled: !!actor && !actorFetching && isAuthenticated,
    retry: false,
    staleTime: 30_000,
  });

  const userRole: AppUserRole =
    roleQuery.data === UserRole__1.admin
      ? "admin"
      : roleQuery.data === UserRole__1.user
        ? "analyst"
        : "guest";

  const isAdmin = userRole === "admin";

  const principal = identity?.getPrincipal().toString() ?? null;

  const logout = () => {
    clear();
    queryClient.clear();
  };

  return {
    isAuthenticated,
    isInitializing,
    isLoggingIn,
    principal,
    userRole,
    isAdmin,
    login,
    logout,
    roleLoading: roleQuery.isLoading || actorFetching,
  };
}
