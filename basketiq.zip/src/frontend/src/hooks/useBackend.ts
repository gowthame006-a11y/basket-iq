import { useActor } from "@caffeineai/core-infrastructure";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createActor } from "../backend";
import type { UserRole } from "../backend";
import type {
  Alert,
  AlertStats,
  AssociationRule,
  AuditEntry,
  ChatMessage,
  ChatResponse,
  DashboardStats,
  DatasetId,
  InventoryItem,
  ProductPair,
  Recommendation,
  StreamingStatus,
  SystemSettings,
  TransactionDataset,
} from "../types";

// ---------------------------------------------------------------------------
// Existing hooks
// ---------------------------------------------------------------------------

export function useTransactionDatasets() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<TransactionDataset[]>({
    queryKey: ["transactionDatasets"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getTransactionDatasets();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useAddTransactionDataset() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      name,
      products,
    }: {
      name: string;
      products: string[][];
    }) => {
      if (!actor) throw new Error("Actor not available");
      return actor.addTransactionDataset(name, products);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["transactionDatasets"] });
      queryClient.invalidateQueries({ queryKey: ["dashboardStats"] });
    },
  });
}

export function useComputeAssociationRules() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      datasetId,
      minSupport,
      minConfidence,
    }: {
      datasetId: DatasetId;
      minSupport: number;
      minConfidence: number;
    }) => {
      if (!actor) throw new Error("Actor not available");
      return actor.computeAssociationRules(
        datasetId,
        minSupport,
        minConfidence,
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["associationRules"] });
      queryClient.invalidateQueries({ queryKey: ["dashboardStats"] });
    },
  });
}

export function useAssociationRules(datasetId: DatasetId | null) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<AssociationRule[]>({
    queryKey: ["associationRules", datasetId?.toString()],
    queryFn: async () => {
      if (!actor || datasetId === null) return [];
      return actor.getAssociationRules(datasetId);
    },
    enabled: !!actor && !isFetching && datasetId !== null,
  });
}

export function useAllAssociationRules() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<AssociationRule[]>({
    queryKey: ["allAssociationRules"],
    queryFn: async () => {
      if (!actor) return [];
      const datasets = await actor.getTransactionDatasets();
      if (datasets.length === 0) return [];
      const allRules = await Promise.all(
        datasets.map((d) => actor.getAssociationRules(d.id)),
      );
      return allRules.flat();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useRecommendations(productName: string, topN = BigInt(10)) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<Recommendation[]>({
    queryKey: ["recommendations", productName, topN.toString()],
    queryFn: async () => {
      if (!actor || !productName) return [];
      return actor.getRecommendations(productName, topN);
    },
    enabled: !!actor && !isFetching && productName.length > 0,
  });
}

export function useTopProductPairs(limit = BigInt(10)) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<ProductPair[]>({
    queryKey: ["topProductPairs", limit.toString()],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getTopProductPairs(limit);
    },
    enabled: !!actor && !isFetching,
  });
}

export function useDashboardStats() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<DashboardStats>({
    queryKey: ["dashboardStats"],
    queryFn: async () => {
      if (!actor) throw new Error("Actor not available");
      return actor.getDashboardStats();
    },
    enabled: !!actor && !isFetching,
  });
}

// ---------------------------------------------------------------------------
// Alert hooks
// ---------------------------------------------------------------------------

export function useAlerts(unreadOnly = false) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<Alert[]>({
    queryKey: ["alerts", unreadOnly],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAlerts(unreadOnly) as Promise<Alert[]>;
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 30_000,
  });
}

export function useMarkAlertRead() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (alertId: bigint) => {
      if (!actor) throw new Error("Actor not available");
      return actor.markAlertRead(alertId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["alerts"] });
      queryClient.invalidateQueries({ queryKey: ["alertStats"] });
    },
  });
}

export function useDismissAlert() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (alertId: bigint) => {
      if (!actor) throw new Error("Actor not available");
      return actor.dismissAlert(alertId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["alerts"] });
      queryClient.invalidateQueries({ queryKey: ["alertStats"] });
    },
  });
}

export function useGenerateAlerts() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Actor not available");
      return actor.generateAlerts();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["alerts"] });
      queryClient.invalidateQueries({ queryKey: ["alertStats"] });
    },
  });
}

export function useAlertStats() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<AlertStats>({
    queryKey: ["alertStats"],
    queryFn: async () => {
      if (!actor) return { total: 0, unread: 0, critical: 0 };
      const raw = await actor.getAlertStats();
      return {
        total: Number(raw.total),
        unread: Number(raw.unread),
        critical: Number(raw.critical),
      };
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 60_000,
  });
}

// ---------------------------------------------------------------------------
// Audit hooks
// ---------------------------------------------------------------------------

export function useAuditLog(page: number, pageSize: number) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<{ entries: AuditEntry[]; total: number; page: number }>({
    queryKey: ["auditLog", page, pageSize],
    queryFn: async () => {
      if (!actor) return { entries: [], total: 0, page };
      const raw = await actor.getAuditLog(BigInt(page), BigInt(pageSize));
      const entries: AuditEntry[] = raw.entries.map((e) => ({
        id: e.id,
        userId: e.userId.toString(),
        action: e.action as unknown as AuditEntry["action"],
        resourceId: e.resourceId ?? null,
        resourceType: e.resourceType ?? null,
        details: e.details,
        timestamp: e.timestamp,
        status: e.status,
      }));
      return { entries, total: Number(raw.total), page: Number(raw.page) };
    },
    enabled: !!actor && !isFetching,
  });
}

export function useExportAuditLogCSV() {
  const { actor } = useActor(createActor);
  return useMutation({
    mutationFn: async ({
      startTime,
      endTime,
    }: {
      startTime: bigint;
      endTime: bigint;
    }) => {
      if (!actor) throw new Error("Actor not available");
      return actor.exportAuditLogCSV(startTime, endTime);
    },
  });
}

// ---------------------------------------------------------------------------
// Chatbot hooks
// ---------------------------------------------------------------------------

export function useQueryChatbot() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      message,
      sessionId,
    }: {
      message: string;
      sessionId: string;
    }): Promise<ChatResponse> => {
      if (!actor) throw new Error("Actor not available");
      const raw = await actor.queryChatbot(message, sessionId);
      return {
        intent: raw.intent as unknown as ChatResponse["intent"],
        answer: raw.answer,
        confidence: raw.confidence,
        products: raw.products,
        rules: raw.rules,
      };
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({
        queryKey: ["chatHistory", variables.sessionId],
      });
    },
  });
}

export function useChatHistory(sessionId: string) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<ChatMessage[]>({
    queryKey: ["chatHistory", sessionId],
    queryFn: async () => {
      if (!actor || !sessionId) return [];
      const raw = await actor.getChatHistory(sessionId);
      return raw.map((m) => ({
        id: m.id,
        sessionId: m.sessionId,
        userId: m.userId.toString(),
        isUser: m.isUser,
        content: m.content,
        timestamp: m.timestamp,
        relatedProducts: m.relatedProducts,
        relatedRules: m.relatedRules,
      }));
    },
    enabled: !!actor && !isFetching && sessionId.length > 0,
  });
}

export function useClearChatHistory() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (sessionId: string) => {
      if (!actor) throw new Error("Actor not available");
      return actor.clearChatHistory(sessionId);
    },
    onSuccess: (_data, sessionId) => {
      queryClient.invalidateQueries({ queryKey: ["chatHistory", sessionId] });
    },
  });
}

// ---------------------------------------------------------------------------
// Admin hooks
// ---------------------------------------------------------------------------

export function useAllUsers() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<Array<[string, UserRole]>>({
    queryKey: ["allUsers"],
    queryFn: async () => {
      if (!actor) return [];
      const raw = await actor.getAllUsers();
      return raw.map(
        ([uid, role]) => [uid.toString(), role] as [string, UserRole],
      );
    },
    enabled: !!actor && !isFetching,
  });
}

export function useUpdateUserRole() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      userId,
      newRole,
    }: {
      userId: string;
      newRole: UserRole;
    }) => {
      if (!actor) throw new Error("Actor not available");
      const { Principal } = await import("@icp-sdk/core/principal");
      return actor.updateUserRole(Principal.fromText(userId), newRole);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["allUsers"] });
    },
  });
}

export function useSystemSettings() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<SystemSettings>({
    queryKey: ["systemSettings"],
    queryFn: async () => {
      if (!actor) throw new Error("Actor not available");
      const raw = await actor.getSystemSettings();
      return {
        pollingIntervalSecs: Number(raw.pollingIntervalSecs),
        alertThresholdLowSales: raw.alertThresholdLowSales,
        alertThresholdTrending: raw.alertThresholdTrending,
        nlpServiceEndpoint: raw.nlpServiceEndpoint,
        abTestDurationDays: Number(raw.abTestDurationDays),
        inventoryWarningLevel: Number(raw.inventoryWarningLevel),
        streamingAutoGenerateRate: Number(raw.streamingAutoGenerateRate),
      };
    },
    enabled: !!actor && !isFetching,
  });
}

export function useUpdateSystemSettings() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (settings: SystemSettings) => {
      if (!actor) throw new Error("Actor not available");
      const payload = {
        pollingIntervalSecs: BigInt(Math.round(settings.pollingIntervalSecs)),
        alertThresholdLowSales: settings.alertThresholdLowSales,
        alertThresholdTrending: settings.alertThresholdTrending,
        nlpServiceEndpoint: settings.nlpServiceEndpoint,
        abTestDurationDays: BigInt(Math.round(settings.abTestDurationDays)),
        inventoryWarningLevel: BigInt(
          Math.round(settings.inventoryWarningLevel),
        ),
        streamingAutoGenerateRate: BigInt(
          Math.round(settings.streamingAutoGenerateRate),
        ),
      };
      return actor.updateSystemSettings(payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["systemSettings"] });
    },
  });
}

export function useInventoryItems() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<InventoryItem[]>({
    queryKey: ["inventoryItems"],
    queryFn: async () => {
      if (!actor) return [];
      const raw = await actor.getInventoryItems();
      return raw.map((item) => ({
        productId: item.productId,
        productName: item.productName,
        stockLevel: Number(item.stockLevel),
        reorderPoint: Number(item.reorderPoint),
        isInStock: item.isInStock,
        lastUpdated: item.lastUpdated,
      }));
    },
    enabled: !!actor && !isFetching,
  });
}

export function useUpdateInventoryItem() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (item: InventoryItem) => {
      if (!actor) throw new Error("Actor not available");
      const payload = {
        productId: item.productId,
        productName: item.productName,
        stockLevel: BigInt(Math.round(item.stockLevel)),
        reorderPoint: BigInt(Math.round(item.reorderPoint)),
        isInStock: item.isInStock,
        lastUpdated: item.lastUpdated,
      };
      return actor.updateInventoryItem(payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["inventoryItems"] });
    },
  });
}

export function useStreamingStatus() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery<StreamingStatus>({
    queryKey: ["streamingStatus"],
    queryFn: async () => {
      if (!actor)
        return {
          isRunning: false,
          transactionsGenerated: 0,
          lastGeneratedAt: null,
        };
      const raw = await actor.getStreamingStatus();
      return {
        isRunning: raw.isRunning,
        transactionsGenerated: Number(raw.transactionsGenerated),
        lastGeneratedAt: raw.lastGeneratedAt ?? null,
      };
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 10_000,
  });
}

export function useToggleStreamingMode() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (enabled: boolean) => {
      if (!actor) throw new Error("Actor not available");
      return actor.toggleStreamingMode(enabled);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["streamingStatus"] });
    },
  });
}

export function useGenerateSyntheticTransaction() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Actor not available");
      return actor.generateSyntheticTransaction();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["streamingStatus"] });
      queryClient.invalidateQueries({ queryKey: ["dashboardStats"] });
    },
  });
}

// Re-export UserRole for pages that need it
export type { UserRole };
