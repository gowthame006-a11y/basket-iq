import type { Principal } from "@icp-sdk/core/principal";

export type UserId = Principal;
export type Timestamp = bigint;
export type DatasetId = bigint;
export type RuleId = bigint;

export interface TransactionDataset {
  id: DatasetId;
  name: string;
  uploadTimestamp: Timestamp;
  uploadedBy: UserId;
  recordCount: bigint;
}

export interface AssociationRule {
  id: RuleId;
  datasetId: DatasetId;
  support: number;
  lift: number;
  confidence: number;
  antecedent: string;
  consequent: string;
}

export interface Recommendation {
  support: number;
  lift: number;
  confidence: number;
  product: string;
}

export interface ProductPair {
  support: number;
  productA: string;
  productB: string;
  coOccurrences: bigint;
}

export interface DashboardStats {
  totalProducts: bigint;
  avgLift: number;
  topProducts: Array<string>;
  totalDatasets: bigint;
  totalTransactions: bigint;
  totalRules: bigint;
}

export type AppUserRole = "admin" | "analyst" | "viewer" | "guest";

// RFM
export type RFMSegment =
  | "champions"
  | "loyal"
  | "atRisk"
  | "lost"
  | "newCustomer"
  | "potential";

export interface RFMScore {
  userId: string;
  recency: number;
  frequency: number;
  monetary: number;
  rfmScore: number;
  segment: RFMSegment;
  computedAt: bigint;
}

export interface RFMDistribution {
  segment: RFMSegment;
  count: number;
  percentage: number;
}

// Inventory
export type InventoryStatus = "inStock" | "lowStock" | "outOfStock";

export interface InventoryItem {
  productId: string;
  productName: string;
  stockLevel: number;
  reorderPoint: number;
  isInStock: boolean;
  lastUpdated: bigint;
}

// Pricing
export interface PricingRecommendation {
  productId: string;
  productName: string;
  currentPrice: number;
  suggestedPrice: number;
  pricingReason: string;
  demandScore: number;
  associationStrength: number;
  expectedRevenueLift: number;
}

// Alerts
export type AlertType =
  | "lowSales"
  | "trendingProduct"
  | "inventoryWarning"
  | "ruleDecay"
  | "newInsight";

export type AlertSeverity = "info" | "warning" | "critical";

export interface Alert {
  id: bigint;
  alertType: AlertType;
  severity: AlertSeverity;
  title: string;
  message: string;
  productId?: string;
  metricValue?: number;
  threshold?: number;
  createdAt: bigint;
  isRead: boolean;
  isDismissed: boolean;
}

export interface AlertStats {
  total: number;
  unread: number;
  critical: number;
}

// Audit
export type AuditActionType =
  | "userLogin"
  | "datasetUpload"
  | "rulesComputed"
  | "recommendationViewed"
  | "alertDismissed"
  | "chatbotQuery"
  | "roleChanged"
  | "settingsChanged"
  | "inventoryUpdated";

export interface AuditEntry {
  id: bigint;
  userId: string;
  action: AuditActionType;
  resourceId: string | null;
  resourceType: string | null;
  details: string;
  timestamp: bigint;
  status: string;
}

// Chatbot
export type ChatIntent =
  | "whatSellsWith"
  | "showMargins"
  | "recommendBySegment"
  | "demandForecast"
  | "generalQuery";

export interface ChatMessage {
  id: bigint;
  sessionId: string;
  userId: string;
  isUser: boolean;
  content: string;
  timestamp: bigint;
  relatedProducts: string[];
  relatedRules: bigint[];
}

export interface ChatResponse {
  intent: ChatIntent;
  answer: string;
  confidence: number;
  products: string[];
  rules: bigint[];
}

// A/B Testing
export type ABTestVariant = "control" | "treatment";
export type ABTestStatus = "running" | "completed" | "paused";

export interface ABTest {
  id: bigint;
  name: string;
  description: string;
  startedAt: bigint;
  endedAt: bigint | null;
  controlAlgorithm: string;
  treatmentAlgorithm: string;
  status: ABTestStatus;
}

export interface ABTestSummary {
  testId: bigint;
  controlPrecision: number;
  treatmentPrecision: number;
  controlConversions: number;
  treatmentConversions: number;
  winner: ABTestVariant | null;
  pValue: number;
}

// System
export interface SystemSettings {
  pollingIntervalSecs: number;
  alertThresholdLowSales: number;
  alertThresholdTrending: number;
  nlpServiceEndpoint: string;
  abTestDurationDays: number;
  inventoryWarningLevel: number;
  streamingAutoGenerateRate: number;
}

export interface StreamingStatus {
  isRunning: boolean;
  transactionsGenerated: number;
  lastGeneratedAt: bigint | null;
}

export interface PaginatedResult<T> {
  items: T[];
  total: number;
  page: number;
}
