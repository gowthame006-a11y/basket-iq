import { useActor } from "@caffeineai/core-infrastructure";
import { useCallback, useRef, useState } from "react";
import { toast } from "sonner";
import { createActor } from "../backend";
import { Layout } from "../components/Layout";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "../components/ui/dialog";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Skeleton } from "../components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import { useAuth } from "../hooks/useAuth";
import {
  useAddTransactionDataset,
  useComputeAssociationRules,
  useTransactionDatasets,
} from "../hooks/useBackend";
import type { TransactionDataset } from "../types";

// ─── Sample dataset (50 transactions) ───────────────────────────────────────
const SAMPLE_TRANSACTIONS: string[][] = [
  ["Bread", "Milk", "Butter"],
  ["Bread", "Butter", "Eggs"],
  ["Milk", "Eggs", "Yogurt"],
  ["Bread", "Milk", "Cheese"],
  ["Coffee", "Bread", "Butter"],
  ["Coffee", "Milk", "Sugar"],
  ["Cereal", "Milk", "Yogurt"],
  ["Bread", "Jam", "Butter"],
  ["Chicken", "Rice", "Vegetables"],
  ["Pasta", "Tomato Sauce", "Cheese"],
  ["Bread", "Milk", "Butter", "Eggs"],
  ["Coffee", "Sugar", "Creamer"],
  ["Tea", "Sugar", "Milk"],
  ["Cereal", "Milk", "Banana"],
  ["Diapers", "Beer", "Chips"],
  ["Diapers", "Baby Wipes", "Beer"],
  ["Beer", "Chips", "Salsa"],
  ["Wine", "Cheese", "Crackers"],
  ["Wine", "Bread", "Cheese"],
  ["Fruit", "Yogurt", "Granola"],
  ["Bread", "Butter", "Jam"],
  ["Milk", "Cereal", "Fruit"],
  ["Coffee", "Bread", "Eggs"],
  ["Pasta", "Cheese", "Bread"],
  ["Chicken", "Vegetables", "Bread"],
  ["Cereal", "Milk", "Sugar"],
  ["Tea", "Milk", "Cookies"],
  ["Bread", "Milk", "Yogurt"],
  ["Butter", "Eggs", "Flour"],
  ["Cheese", "Crackers", "Wine"],
  ["Beer", "Chips", "Diapers"],
  ["Coffee", "Creamer", "Sugar"],
  ["Bread", "Eggs", "Milk"],
  ["Fruit", "Cereal", "Milk"],
  ["Pasta", "Tomato Sauce", "Vegetables"],
  ["Chicken", "Rice", "Sauce"],
  ["Diapers", "Formula", "Baby Wipes"],
  ["Yogurt", "Granola", "Fruit"],
  ["Tea", "Honey", "Lemon"],
  ["Bread", "Ham", "Cheese"],
  ["Milk", "Butter", "Cheese"],
  ["Coffee", "Milk", "Bread"],
  ["Beer", "Nachos", "Salsa"],
  ["Wine", "Crackers", "Grapes"],
  ["Cereal", "Milk", "Honey"],
  ["Bread", "Butter", "Milk"],
  ["Eggs", "Bacon", "Bread"],
  ["Vegetables", "Chicken", "Sauce"],
  ["Pasta", "Bread", "Cheese"],
  ["Milk", "Yogurt", "Cereal"],
];

// ─── CSV helpers ─────────────────────────────────────────────────────────────
function parseCSV(text: string): Map<string, string[]> {
  const lines = text
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean);
  if (lines.length < 2) return new Map();
  const header = lines[0]
    .toLowerCase()
    .split(",")
    .map((h) => h.trim().replace(/"/g, ""));
  const txIdx = header.findIndex((h) => h.includes("transaction"));
  const prodIdx = header.findIndex((h) => h.includes("product"));
  if (txIdx === -1 || prodIdx === -1) return new Map();

  const map = new Map<string, string[]>();
  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(",").map((c) => c.trim().replace(/"/g, ""));
    const txId = cols[txIdx];
    const product = cols[prodIdx];
    if (!txId || !product) continue;
    const existing = map.get(txId) ?? [];
    existing.push(product);
    map.set(txId, existing);
  }
  return map;
}

// ─── Compute Rules Dialog ────────────────────────────────────────────────────
interface ComputeRulesDialogProps {
  dataset: TransactionDataset | null;
  onClose: () => void;
}

function ComputeRulesDialog({ dataset, onClose }: ComputeRulesDialogProps) {
  const [minSupport, setMinSupport] = useState("0.05");
  const [minConfidence, setMinConfidence] = useState("0.3");
  const computeRules = useComputeAssociationRules();

  const handleCompute = async () => {
    if (!dataset) return;
    const support = Number.parseFloat(minSupport);
    const confidence = Number.parseFloat(minConfidence);
    if (Number.isNaN(support) || Number.isNaN(confidence)) {
      toast.error("Please enter valid numeric thresholds.");
      return;
    }
    try {
      await computeRules.mutateAsync({
        datasetId: dataset.id,
        minSupport: support,
        minConfidence: confidence,
      });
      toast.success(`Rules computed for "${dataset.name}"`);
      onClose();
    } catch {
      toast.error("Failed to compute association rules.");
    }
  };

  return (
    <Dialog open={!!dataset} onOpenChange={(open) => !open && onClose()}>
      <DialogContent
        className="sm:max-w-md bg-card border-border"
        data-ocid="compute_rules.dialog"
      >
        <DialogHeader>
          <DialogTitle className="font-display text-foreground">
            Compute Association Rules
          </DialogTitle>
        </DialogHeader>
        {dataset && (
          <p className="text-sm text-muted-foreground font-body">
            Dataset:{" "}
            <span className="text-foreground font-medium">{dataset.name}</span>
          </p>
        )}
        <div className="grid gap-4 py-2">
          <div className="grid gap-1.5">
            <Label
              htmlFor="min-support"
              className="font-body text-xs text-muted-foreground uppercase tracking-wide"
            >
              Min Support (0–1)
            </Label>
            <Input
              id="min-support"
              type="number"
              step="0.01"
              min="0"
              max="1"
              value={minSupport}
              onChange={(e) => setMinSupport(e.target.value)}
              className="bg-background border-border font-body"
              data-ocid="compute_rules.min_support.input"
            />
          </div>
          <div className="grid gap-1.5">
            <Label
              htmlFor="min-confidence"
              className="font-body text-xs text-muted-foreground uppercase tracking-wide"
            >
              Min Confidence (0–1)
            </Label>
            <Input
              id="min-confidence"
              type="number"
              step="0.01"
              min="0"
              max="1"
              value={minConfidence}
              onChange={(e) => setMinConfidence(e.target.value)}
              className="bg-background border-border font-body"
              data-ocid="compute_rules.min_confidence.input"
            />
          </div>
        </div>
        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            onClick={onClose}
            className="border-border font-body"
            data-ocid="compute_rules.cancel_button"
          >
            Cancel
          </Button>
          <Button
            onClick={handleCompute}
            disabled={computeRules.isPending}
            className="bg-accent text-accent-foreground hover:bg-accent/90 font-body"
            data-ocid="compute_rules.confirm_button"
          >
            {computeRules.isPending ? "Computing…" : "Run Analysis"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function UploadPage() {
  const { isAdmin, principal } = useAuth();
  const { data: datasets, isLoading: datasetsLoading } =
    useTransactionDatasets();
  const addDataset = useAddTransactionDataset();

  // Upload state
  const [datasetName, setDatasetName] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Compute rules dialog
  const [computeTarget, setComputeTarget] = useState<TransactionDataset | null>(
    null,
  );

  // User management (admin: list all users with roles)
  const { actor } = useActor(createActor);
  const [users] = useState<Array<{ principal: string; role: string }>>([
    { principal: principal ?? "aaaaa-aa", role: "admin" },
    { principal: "xyzzy-12345-abcde-67890", role: "analyst" },
    { principal: "bbbbb-bbbbb-ccccc-ddddd", role: "analyst" },
  ]);
  const [userRoles, setUserRoles] = useState<Record<string, string>>(
    Object.fromEntries(users.map((u) => [u.principal, u.role])),
  );

  // ─── File drag / drop ────────────────────────────────────────────────────
  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      const file = e.dataTransfer.files[0];
      if (file?.name.endsWith(".csv")) {
        setSelectedFile(file);
        if (!datasetName) setDatasetName(file.name.replace(/\.csv$/i, ""));
      } else {
        toast.error("Only .csv files are accepted.");
      }
    },
    [datasetName],
  );

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] ?? null;
    if (file) {
      setSelectedFile(file);
      if (!datasetName) setDatasetName(file.name.replace(/\.csv$/i, ""));
    }
  };

  // ─── Upload CSV ──────────────────────────────────────────────────────────
  const handleUpload = async () => {
    if (!selectedFile) {
      toast.error("Please select a CSV file.");
      return;
    }
    if (!datasetName.trim()) {
      toast.error("Please enter a dataset name.");
      return;
    }

    setUploadProgress(true);
    try {
      const text = await selectedFile.text();
      const txMap = parseCSV(text);
      if (txMap.size === 0) {
        toast.error(
          "Could not parse CSV. Ensure columns: transaction_id, product_name.",
        );
        return;
      }
      const products = Array.from(txMap.values());
      await addDataset.mutateAsync({ name: datasetName.trim(), products });
      toast.success(
        `Dataset "${datasetName}" uploaded — ${txMap.size} transactions.`,
      );
      setSelectedFile(null);
      setDatasetName("");
      if (fileInputRef.current) fileInputRef.current.value = "";
    } catch {
      toast.error("Upload failed. Please try again.");
    } finally {
      setUploadProgress(false);
    }
  };

  // ─── Load sample data ────────────────────────────────────────────────────
  const handleLoadSample = async () => {
    setUploadProgress(true);
    try {
      await addDataset.mutateAsync({
        name: "Sample Retail Transactions",
        products: SAMPLE_TRANSACTIONS,
      });
      toast.success("Sample dataset loaded — 50 transactions ready.");
    } catch {
      toast.error("Failed to load sample dataset.");
    } finally {
      setUploadProgress(false);
    }
  };

  // ─── Role change ─────────────────────────────────────────────────────────
  const handleRoleChange = async (userPrincipal: string, newRole: string) => {
    try {
      if (actor) {
        // The actor.setUserRole accepts userId + role string
        await actor.setUserRole(
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          userPrincipal as any,
          newRole,
        );
      }
      setUserRoles((prev) => ({ ...prev, [userPrincipal]: newRole }));
      toast.success(`Role updated to "${newRole}"`);
    } catch {
      toast.error("Failed to update user role.");
    }
  };

  const formatDate = (ts: bigint) => {
    return new Date(Number(ts / BigInt(1_000_000))).toLocaleDateString(
      "en-US",
      {
        year: "numeric",
        month: "short",
        day: "numeric",
      },
    );
  };

  const truncatePrincipal = (p: string) =>
    p.length > 20 ? `${p.slice(0, 10)}…${p.slice(-6)}` : p;

  return (
    <Layout
      title="Data Management"
      actions={
        <Badge className="bg-accent/20 text-accent border border-accent/40 font-body text-xs px-2 py-0.5">
          Admin Only
        </Badge>
      }
      data-ocid="upload.page"
    >
      {/* Page subtitle */}
      <p className="text-sm text-muted-foreground font-body mb-6">
        Upload and manage transaction datasets for market basket analysis.
      </p>

      <div className="grid gap-6">
        {/* ─── CSV Upload Card ─────────────────────────────────────────── */}
        <Card className="border-border bg-card" data-ocid="upload.section">
          <CardHeader className="pb-4">
            <CardTitle className="font-display text-base text-foreground flex items-center gap-2">
              <span className="inline-flex h-5 w-5 items-center justify-center rounded bg-accent/20 text-accent text-xs">
                ↑
              </span>
              Upload Transaction Dataset
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            {/* Drop zone */}
            <button
              type="button"
              aria-label="Click or drop CSV file to upload"
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={[
                "relative w-full flex flex-col items-center justify-center gap-3 rounded-lg border-2 border-dashed cursor-pointer transition-colors duration-200 py-10",
                isDragging
                  ? "border-accent bg-accent/10"
                  : selectedFile
                    ? "border-accent/60 bg-accent/5"
                    : "border-border hover:border-accent/50 hover:bg-muted/30",
              ].join(" ")}
              data-ocid="upload.dropzone"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv"
                className="hidden"
                onChange={handleFileChange}
                data-ocid="upload.file_input"
              />
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                <svg
                  aria-hidden="true"
                  className="h-6 w-6 text-muted-foreground"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={1.5}
                    d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                  />
                </svg>
              </div>
              {selectedFile ? (
                <div className="text-center">
                  <p className="font-body text-sm font-medium text-accent">
                    {selectedFile.name}
                  </p>
                  <p className="font-body text-xs text-muted-foreground mt-0.5">
                    {(selectedFile.size / 1024).toFixed(1)} KB · Click to change
                  </p>
                </div>
              ) : (
                <div className="text-center">
                  <p className="font-body text-sm text-foreground font-medium">
                    Drop your CSV file here
                  </p>
                  <p className="font-body text-xs text-muted-foreground mt-0.5">
                    or click to browse · .csv only
                  </p>
                </div>
              )}
            </button>

            {/* CSV format help */}
            <div className="rounded-md border border-border bg-muted/30 p-4">
              <p className="font-body text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                Expected CSV Format
              </p>
              <div className="overflow-x-auto">
                <table className="w-full text-xs font-mono">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-1 pr-8 text-accent font-semibold">
                        transaction_id
                      </th>
                      <th className="text-left py-1 text-accent font-semibold">
                        product_name
                      </th>
                    </tr>
                  </thead>
                  <tbody className="text-muted-foreground">
                    {[
                      ["1001", "Bread"],
                      ["1001", "Milk"],
                      ["1001", "Butter"],
                      ["1002", "Eggs"],
                      ["1002", "Cheese"],
                    ].map(([txId, prod]) => (
                      <tr
                        key={`${txId}-${prod}`}
                        className="border-b border-border/50 last:border-0"
                      >
                        <td className="py-1 pr-8">{txId}</td>
                        <td className="py-1">{prod}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Dataset name + upload */}
            <div className="flex gap-3 items-end">
              <div className="flex-1 grid gap-1.5">
                <Label
                  htmlFor="dataset-name"
                  className="font-body text-xs text-muted-foreground uppercase tracking-wide"
                >
                  Dataset Name
                </Label>
                <Input
                  id="dataset-name"
                  value={datasetName}
                  onChange={(e) => setDatasetName(e.target.value)}
                  placeholder="e.g. Q1 2026 Sales"
                  className="bg-background border-border font-body"
                  data-ocid="upload.dataset_name.input"
                />
              </div>
              <Button
                onClick={handleUpload}
                disabled={
                  uploadProgress || !selectedFile || !datasetName.trim()
                }
                className="bg-accent text-accent-foreground hover:bg-accent/90 font-body shrink-0"
                data-ocid="upload.upload_button"
              >
                {uploadProgress ? (
                  <span className="flex items-center gap-2">
                    <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-accent-foreground border-t-transparent" />
                    Uploading…
                  </span>
                ) : (
                  "Upload Dataset"
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* ─── Sample Data Card ────────────────────────────────────────── */}
        <Card className="border-border bg-card" data-ocid="sample_data.section">
          <CardHeader className="pb-3">
            <CardTitle className="font-display text-base text-foreground flex items-center gap-2">
              <span className="inline-flex h-5 w-5 items-center justify-center rounded bg-primary/20 text-primary text-xs">
                ★
              </span>
              Sample Dataset
            </CardTitle>
          </CardHeader>
          <CardContent className="flex items-center justify-between gap-4">
            <div>
              <p className="font-body text-sm text-foreground">
                Load a pre-defined set of 50 retail transactions
              </p>
              <p className="font-body text-xs text-muted-foreground mt-0.5">
                Includes grocery, beverage, and household items — great for
                demonstration.
              </p>
            </div>
            <Button
              variant="outline"
              onClick={handleLoadSample}
              disabled={uploadProgress}
              className="border-border font-body shrink-0"
              data-ocid="sample_data.load_button"
            >
              {uploadProgress ? "Loading…" : "Load Sample Dataset"}
            </Button>
          </CardContent>
        </Card>

        {/* ─── Existing Datasets Table ─────────────────────────────────── */}
        <Card className="border-border bg-card" data-ocid="datasets.section">
          <CardHeader className="pb-3">
            <CardTitle className="font-display text-base text-foreground flex items-center gap-2">
              <span className="inline-flex h-5 w-5 items-center justify-center rounded bg-accent/20 text-accent text-xs">
                ≡
              </span>
              Existing Datasets
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {datasetsLoading ? (
              <div className="p-6 space-y-3" data-ocid="datasets.loading_state">
                {[1, 2, 3].map((i) => (
                  <Skeleton
                    key={i}
                    className="h-10 w-full rounded-md bg-muted"
                  />
                ))}
              </div>
            ) : !datasets || datasets.length === 0 ? (
              <div
                className="flex flex-col items-center justify-center py-14 gap-3 text-center px-6"
                data-ocid="datasets.empty_state"
              >
                <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center">
                  <svg
                    aria-hidden="true"
                    className="h-6 w-6 text-muted-foreground"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"
                    />
                  </svg>
                </div>
                <div>
                  <p className="font-body text-sm font-medium text-foreground">
                    No datasets yet
                  </p>
                  <p className="font-body text-xs text-muted-foreground mt-0.5">
                    Upload a CSV or load the sample dataset above.
                  </p>
                </div>
              </div>
            ) : (
              <Table data-ocid="datasets.table">
                <TableHeader>
                  <TableRow className="border-border hover:bg-transparent">
                    <TableHead className="font-body text-xs text-muted-foreground uppercase tracking-wide pl-6">
                      Name
                    </TableHead>
                    <TableHead className="font-body text-xs text-muted-foreground uppercase tracking-wide text-right">
                      Records
                    </TableHead>
                    <TableHead className="font-body text-xs text-muted-foreground uppercase tracking-wide">
                      Uploaded On
                    </TableHead>
                    <TableHead className="font-body text-xs text-muted-foreground uppercase tracking-wide text-right pr-6">
                      Actions
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {datasets.map((ds, idx) => (
                    <DatasetRow
                      key={ds.id.toString()}
                      dataset={ds}
                      index={idx + 1}
                      formatDate={formatDate}
                      onCompute={() => setComputeTarget(ds)}
                    />
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* ─── User Management ─────────────────────────────────────────── */}
        {isAdmin && (
          <Card
            className="border-border bg-card"
            data-ocid="user_management.section"
          >
            <CardHeader className="pb-3">
              <CardTitle className="font-display text-base text-foreground flex items-center gap-2">
                <span className="inline-flex h-5 w-5 items-center justify-center rounded bg-primary/20 text-primary text-xs">
                  👤
                </span>
                User Management
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <Table data-ocid="user_management.table">
                <TableHeader>
                  <TableRow className="border-border hover:bg-transparent">
                    <TableHead className="font-body text-xs text-muted-foreground uppercase tracking-wide pl-6">
                      Principal ID
                    </TableHead>
                    <TableHead className="font-body text-xs text-muted-foreground uppercase tracking-wide">
                      Role
                    </TableHead>
                    <TableHead className="font-body text-xs text-muted-foreground uppercase tracking-wide text-right pr-6">
                      Change Role
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((user, idx) => (
                    <TableRow
                      key={user.principal}
                      className="border-border"
                      data-ocid={`user_management.item.${idx + 1}`}
                    >
                      <TableCell className="pl-6 font-mono text-xs text-muted-foreground">
                        {truncatePrincipal(user.principal)}
                        {user.principal === principal && (
                          <Badge className="ml-2 text-[10px] bg-accent/20 text-accent border-accent/40 border">
                            you
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge
                          className={
                            userRoles[user.principal] === "admin"
                              ? "bg-primary/20 text-primary border-primary/40 border font-body text-xs"
                              : "bg-muted text-muted-foreground border-border border font-body text-xs"
                          }
                        >
                          {userRoles[user.principal] ?? user.role}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right pr-6">
                        <select
                          value={userRoles[user.principal] ?? user.role}
                          onChange={(e) =>
                            handleRoleChange(user.principal, e.target.value)
                          }
                          className="rounded border border-border bg-background px-2 py-1 text-xs font-body text-foreground focus:outline-none focus:ring-1 focus:ring-accent"
                          data-ocid={`user_management.role_select.${idx + 1}`}
                        >
                          <option value="admin">admin</option>
                          <option value="analyst">analyst</option>
                        </select>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Compute Rules Dialog */}
      <ComputeRulesDialog
        dataset={computeTarget}
        onClose={() => setComputeTarget(null)}
      />
    </Layout>
  );
}

// ─── Dataset Row Component ────────────────────────────────────────────────────
interface DatasetRowProps {
  dataset: TransactionDataset;
  index: number;
  formatDate: (ts: bigint) => string;
  onCompute: () => void;
}

function DatasetRow({
  dataset,
  index,
  formatDate,
  onCompute,
}: DatasetRowProps) {
  const handleDelete = async () => {
    // Backend delete not exposed — show informational toast
    toast.info(
      "Dataset deletion requires backend support. Contact your administrator.",
    );
  };

  return (
    <TableRow
      className="border-border hover:bg-muted/20 transition-colors"
      data-ocid={`datasets.item.${index}`}
    >
      <TableCell className="pl-6 font-body text-sm text-foreground font-medium">
        {dataset.name}
      </TableCell>
      <TableCell className="text-right font-mono text-sm text-muted-foreground">
        {dataset.recordCount.toString()}
      </TableCell>
      <TableCell className="font-body text-sm text-muted-foreground">
        {formatDate(dataset.uploadTimestamp)}
      </TableCell>
      <TableCell className="text-right pr-6">
        <div className="flex items-center justify-end gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={onCompute}
            className="border-accent/40 text-accent hover:bg-accent/10 font-body text-xs h-7 px-3"
            data-ocid={`datasets.compute_rules_button.${index}`}
          >
            Compute Rules
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={handleDelete}
            className="border-destructive/40 text-destructive hover:bg-destructive/10 font-body text-xs h-7 px-3"
            data-ocid={`datasets.delete_button.${index}`}
          >
            Delete
          </Button>
        </div>
      </TableCell>
    </TableRow>
  );
}
