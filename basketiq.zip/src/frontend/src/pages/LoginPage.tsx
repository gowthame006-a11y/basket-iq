import { Button } from "@/components/ui/button";
import { Navigate } from "@tanstack/react-router";
import { ShoppingCart } from "lucide-react";
import { useAuth } from "../hooks/useAuth";

export default function LoginPage() {
  const { isAuthenticated, isInitializing, isLoggingIn, login } = useAuth();

  if (isAuthenticated) {
    return <Navigate to="/dashboard" />;
  }

  return (
    <div
      className="flex min-h-screen items-center justify-center bg-background"
      data-ocid="login.page"
    >
      {/* Subtle grid background */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "linear-gradient(var(--border) 1px, transparent 1px), linear-gradient(90deg, var(--border) 1px, transparent 1px)",
          backgroundSize: "40px 40px",
        }}
      />

      <div className="relative z-10 w-full max-w-md px-4">
        <div className="rounded-lg border border-border bg-card p-8 shadow-lg">
          {/* Brand */}
          <div className="mb-8 flex flex-col items-center text-center">
            <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-xl bg-accent/15 ring-1 ring-accent/30">
              <ShoppingCart className="h-7 w-7 text-accent" />
            </div>
            <h1 className="font-display text-3xl font-semibold text-foreground">
              BasketIQ
            </h1>
            <p className="mt-2 text-sm text-muted-foreground font-body leading-relaxed">
              Intelligent retail recommendations powered by
              <br />
              market basket analysis
            </p>
          </div>

          {/* Divider */}
          <div className="mb-6 flex items-center gap-3">
            <div className="h-px flex-1 bg-border" />
            <span className="text-xs text-muted-foreground font-body uppercase tracking-wider">
              Sign in to continue
            </span>
            <div className="h-px flex-1 bg-border" />
          </div>

          {/* Login button */}
          <Button
            className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-body font-medium transition-smooth"
            size="lg"
            disabled={isInitializing || isLoggingIn}
            onClick={login}
            data-ocid="login.submit_button"
          >
            {isInitializing
              ? "Initializing..."
              : isLoggingIn
                ? "Connecting..."
                : "Sign in with Internet Identity"}
          </Button>

          <p className="mt-4 text-center text-xs text-muted-foreground font-body">
            Secure, decentralized authentication via{" "}
            <span className="text-foreground">Internet Identity</span>
          </p>
        </div>

        {/* Feature callouts */}
        <div className="mt-6 grid grid-cols-3 gap-3 text-center">
          {[
            { label: "Association Rules", icon: "⛓" },
            { label: "Cross-Sell Insights", icon: "🎯" },
            { label: "FP-Growth Analysis", icon: "📊" },
          ].map((f) => (
            <div
              key={f.label}
              className="rounded-md border border-border bg-card/50 px-2 py-3"
            >
              <div className="text-lg">{f.icon}</div>
              <div className="mt-1 text-[10px] text-muted-foreground font-body leading-tight">
                {f.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
