import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  BookOpen,
  Brain,
  Clock,
  ExternalLink,
  GitBranch,
  Info,
  Lock,
  Moon,
  Network,
  RefreshCw,
  ShieldCheck,
  User,
} from "lucide-react";
import { Layout } from "../components/Layout";
import { useAuth } from "../hooks/useAuth";
import { useSystemSettings } from "../hooks/useBackend";

// ─── Role badge ───────────────────────────────────────────────────────────────

function roleBadgeClass(role: string) {
  if (role === "admin")
    return "bg-[oklch(0.68_0.2_187/0.15)] text-[oklch(0.68_0.2_187)] border-[oklch(0.68_0.2_187/0.3)]";
  if (role === "analyst")
    return "bg-[oklch(0.62_0.2_264/0.15)] text-[oklch(0.62_0.2_264)] border-[oklch(0.62_0.2_264/0.3)]";
  return "bg-secondary/20 text-muted-foreground border-border";
}

// ─── Algorithm card ───────────────────────────────────────────────────────────

interface AlgoCardProps {
  icon: React.ReactNode;
  name: string;
  category: string;
  description: string;
  metrics: string[];
}

function AlgoCard({
  icon,
  name,
  category,
  description,
  metrics,
}: AlgoCardProps) {
  return (
    <Card className="bg-card border-border hover:border-accent/30 transition-smooth">
      <CardContent className="px-4 py-4 space-y-3">
        <div className="flex items-start gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-accent/10 text-accent flex-shrink-0">
            {icon}
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <p className="text-sm font-display font-semibold text-foreground">
                {name}
              </p>
              <Badge
                variant="outline"
                className="text-[9px] h-4 px-1.5 text-muted-foreground border-border"
              >
                {category}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground font-body mt-1 leading-relaxed">
              {description}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {metrics.map((m) => (
            <span
              key={m}
              className="rounded bg-secondary/20 px-2 py-0.5 text-[10px] font-mono text-muted-foreground"
            >
              {m}
            </span>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Section header ───────────────────────────────────────────────────────────

function SectionHeader({
  icon,
  title,
  subtitle,
}: {
  icon: React.ReactNode;
  title: string;
  subtitle?: string;
}) {
  return (
    <div className="flex items-start gap-3">
      <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary/10 text-primary flex-shrink-0 mt-0.5">
        {icon}
      </div>
      <div>
        <h2 className="text-base font-display font-semibold text-foreground">
          {title}
        </h2>
        {subtitle && (
          <p className="text-xs text-muted-foreground font-body mt-0.5">
            {subtitle}
          </p>
        )}
      </div>
    </div>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────

export default function SettingsPage() {
  const { principal, userRole } = useAuth();
  const { data: settings } = useSystemSettings();

  const memberSince = "January 2025"; // Static — no account creation date from backend

  return (
    <Layout title="Settings">
      <div className="max-w-2xl space-y-8" data-ocid="settings.page">
        {/* ── My Profile ── */}
        <section data-ocid="settings.profile.section">
          <SectionHeader
            icon={<User className="h-4 w-4" />}
            title="My Profile"
            subtitle="Your account identity on the Internet Computer"
          />

          <Card className="bg-card border-border mt-4">
            <CardContent className="px-5 py-5 space-y-4">
              <div className="space-y-1.5">
                <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-body">
                  Principal ID
                </p>
                <div className="flex items-start gap-2">
                  <p
                    className="text-xs font-mono text-foreground break-all bg-muted/20 rounded px-3 py-2 flex-1 border border-border"
                    data-ocid="settings.profile.principal"
                  >
                    {principal ?? "Loading…"}
                  </p>
                </div>
                <p className="text-[11px] text-muted-foreground font-body">
                  Your unique Internet Identity principal — use this to grant
                  access on other platforms.
                </p>
              </div>

              <Separator className="bg-border" />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-body">
                    Role
                  </p>
                  <Badge
                    variant="outline"
                    className={`text-xs px-2.5 py-0.5 font-body ${roleBadgeClass(userRole)}`}
                    data-ocid="settings.profile.role_badge"
                  >
                    <ShieldCheck className="h-3 w-3 mr-1.5" />
                    {userRole}
                  </Badge>
                </div>
                <div className="text-right space-y-0.5">
                  <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-body">
                    Member Since
                  </p>
                  <div className="flex items-center gap-1.5 text-xs text-foreground font-body justify-end">
                    <Clock className="h-3 w-3 text-muted-foreground" />
                    {memberSince}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* ── Preferences ── */}
        <section data-ocid="settings.preferences.section">
          <SectionHeader
            icon={<Moon className="h-4 w-4" />}
            title="Preferences"
            subtitle="Display and data refresh configuration"
          />

          <Card className="bg-card border-border mt-4">
            <CardContent className="px-5 py-5 space-y-4">
              {/* Dark mode — locked */}
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <p className="text-sm font-body text-foreground">Dark Mode</p>
                  <p className="text-xs text-muted-foreground font-body">
                    BasketIQ is optimized for dark environments.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <div
                    className="flex items-center gap-1.5 rounded-md bg-accent/10 border border-accent/20 px-3 py-1.5"
                    data-ocid="settings.preferences.dark_mode_toggle"
                  >
                    <Moon className="h-3.5 w-3.5 text-accent" />
                    <span className="text-xs font-body text-accent">
                      Always On
                    </span>
                    <Lock className="h-3 w-3 text-muted-foreground ml-1" />
                  </div>
                </div>
              </div>

              <Separator className="bg-border" />

              {/* Data refresh interval info */}
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <p className="text-sm font-body text-foreground">
                    Data Refresh Interval
                  </p>
                  <p className="text-xs text-muted-foreground font-body">
                    How often the dashboard polls for updates.
                  </p>
                </div>
                <div className="flex items-center gap-1.5">
                  <RefreshCw className="h-3.5 w-3.5 text-muted-foreground" />
                  <span
                    className="text-sm font-mono text-foreground"
                    data-ocid="settings.preferences.refresh_interval"
                  >
                    {settings ? `${settings.pollingIntervalSecs}s` : "—"}
                  </span>
                  <span className="text-xs text-muted-foreground font-body">
                    (set by admin)
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* ── About BasketIQ ── */}
        <section data-ocid="settings.about.section">
          <SectionHeader
            icon={<Info className="h-4 w-4" />}
            title="About BasketIQ"
            subtitle="Version information and algorithm reference"
          />

          {/* Version card */}
          <Card className="bg-card border-border mt-4 mb-4">
            <CardContent className="px-5 py-4">
              <div className="grid grid-cols-3 divide-x divide-border">
                {[
                  { label: "Version", value: "1.0.0" },
                  { label: "Engine", value: "ICP Canister" },
                  { label: "Build", value: "2026.04.19" },
                ].map((item) => (
                  <div
                    key={item.label}
                    className="px-4 first:pl-0 last:pr-0 text-center"
                  >
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">
                      {item.label}
                    </p>
                    <p className="text-sm font-mono text-foreground mt-1">
                      {item.value}
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Algorithm cards */}
          <div className="grid grid-cols-2 gap-3">
            <AlgoCard
              icon={<GitBranch className="h-4 w-4" />}
              name="Apriori"
              category="Association"
              description="Classic breadth-first frequent itemset mining. Generates rules using support, confidence, and lift thresholds."
              metrics={["support", "confidence", "lift"]}
            />
            <AlgoCard
              icon={<Network className="h-4 w-4" />}
              name="FP-Growth"
              category="Association"
              description="FP-tree based mining — faster than Apriori on dense datasets. No candidate generation step."
              metrics={["min-support", "fp-tree", "conditional patterns"]}
            />
            <AlgoCard
              icon={<Brain className="h-4 w-4" />}
              name="Collaborative Filtering"
              category="Recommendation"
              description="Item-item similarity based on co-purchase patterns. Discovers latent affinities beyond direct rule overlap."
              metrics={["cosine similarity", "top-N", "co-occurrence"]}
            />
            <AlgoCard
              icon={<BookOpen className="h-4 w-4" />}
              name="Sequence Modeling"
              category="Prediction"
              description="Temporal purchase sequence analysis. Predicts next likely product using purchase order and session context."
              metrics={["sequence", "next-basket", "temporal"]}
            />
          </div>

          {/* Docs link */}
          <div className="mt-4 flex items-center justify-center">
            <a
              href="https://caffeine.ai?utm_source=basketiq-settings&utm_medium=referral"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-xs text-accent hover:text-accent/80 font-body transition-smooth"
              data-ocid="settings.about.docs_link"
            >
              <ExternalLink className="h-3.5 w-3.5" />
              Learn more about the BasketIQ platform
            </a>
          </div>
        </section>
      </div>
    </Layout>
  );
}
