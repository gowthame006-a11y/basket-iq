import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertCircle,
  ArrowDown,
  ArrowUp,
  ArrowUpDown,
  BarChart3,
  CheckCircle2,
  Layers,
  Percent,
  Search,
  TrendingUp,
  Zap,
} from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Layout } from "../components/Layout";
import {
  useAssociationRules,
  useComputeAssociationRules,
  useTransactionDatasets,
} from "../hooks/useBackend";
import type { AssociationRule, DatasetId } from "../types";

// ─── Types ───────────────────────────────────────────────────────────────────

type SortKey = "antecedent" | "consequent" | "support" | "confidence" | "lift";
type SortDir = "asc" | "desc";

interface LiftMeta {
  label: string;
  colorClass: string;
  dotClass: string;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function getLiftMeta(lift: number): LiftMeta {
  if (lift > 2)
    return {
      label: "Strong",
      colorClass: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
      dotClass: "bg-emerald-400",
    };
  if (lift >= 1.5)
    return {
      label: "Good",
      colorClass: "bg-accent/15 text-accent border-accent/30",
      dotClass: "bg-accent",
    };
  if (lift >= 1.2)
    return {
      label: "Moderate",
      colorClass: "bg-amber-500/15 text-amber-400 border-amber-500/30",
      dotClass: "bg-amber-400",
    };
  return {
    label: "Weak",
    colorClass: "bg-muted text-muted-foreground border-border",
    dotClass: "bg-muted-foreground",
  };
}

function fmtPct(v: number) {
  return `${(v * 100).toFixed(2)}%`;
}

function fmtLift(v: number) {
  return v.toFixed(3);
}

function supportColor(v: number) {
  if (v >= 0.2) return "text-emerald-400";
  if (v >= 0.08) return "text-amber-400";
  return "text-rose-400";
}

function confidenceColor(v: number) {
  if (v >= 0.6) return "text-emerald-400";
  if (v >= 0.35) return "text-amber-400";
  return "text-rose-400";
}

function liftColor(v: number) {
  if (v > 2) return "text-emerald-400";
  if (v >= 1.5) return "text-accent";
  if (v >= 1.2) return "text-amber-400";
  return "text-muted-foreground";
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function SortIcon({
  col,
  sortKey,
  sortDir,
}: {
  col: SortKey;
  sortKey: SortKey;
  sortDir: SortDir;
}) {
  if (col !== sortKey)
    return <ArrowUpDown className="ml-1.5 h-3.5 w-3.5 opacity-40" />;
  return sortDir === "asc" ? (
    <ArrowUp className="ml-1.5 h-3.5 w-3.5 text-accent" />
  ) : (
    <ArrowDown className="ml-1.5 h-3.5 w-3.5 text-accent" />
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  sub,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
  sub?: string;
}) {
  return (
    <div className="flex items-center gap-3 rounded-lg border border-border bg-card px-4 py-3">
      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-accent/10">
        <Icon className="h-4 w-4 text-accent" />
      </div>
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="truncate font-display text-lg font-semibold text-foreground leading-tight">
          {value}
        </p>
        {sub && <p className="text-xs text-muted-foreground">{sub}</p>}
      </div>
    </div>
  );
}

function ControlSlider({
  id,
  label,
  min,
  max,
  step,
  value,
  onChange,
  displayValue,
}: {
  id: string;
  label: string;
  min: number;
  max: number;
  step: number;
  value: number;
  onChange: (v: number) => void;
  displayValue: string;
}) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <Label htmlFor={id} className="text-sm text-foreground">
          {label}
        </Label>
        <span className="rounded bg-accent/10 px-2 py-0.5 font-mono text-xs text-accent">
          {displayValue}
        </span>
      </div>
      <input
        id={id}
        data-ocid={id}
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number.parseFloat(e.target.value))}
        className="h-1.5 w-full cursor-pointer appearance-none rounded-full bg-muted accent-accent"
      />
      <div className="flex justify-between text-xs text-muted-foreground">
        <span>{min}</span>
        <span>{max}</span>
      </div>
    </div>
  );
}

// ─── Main Page ─────────────────────────────────────────────────────────────────

export default function RulesPage() {
  const { data: datasets = [], isLoading: datasetsLoading } =
    useTransactionDatasets();

  const [selectedDatasetId, setSelectedDatasetId] = useState<DatasetId | null>(
    null,
  );
  const [minSupport, setMinSupport] = useState(0.05);
  const [minConfidence, setMinConfidence] = useState(0.3);
  const [sortKey, setSortKey] = useState<SortKey>("lift");
  const [sortDir, setSortDir] = useState<SortDir>("desc");
  const [search, setSearch] = useState("");

  // Auto-select first dataset once loaded
  const effectiveDatasetId = useMemo(() => {
    if (selectedDatasetId !== null) return selectedDatasetId;
    if (datasets.length > 0) return datasets[0].id;
    return null;
  }, [selectedDatasetId, datasets]);

  const {
    data: rules = [],
    isLoading: rulesLoading,
    isError: rulesError,
  } = useAssociationRules(effectiveDatasetId);

  const computeMutation = useComputeAssociationRules();

  const handleCompute = () => {
    if (effectiveDatasetId === null) {
      toast.error("Select a dataset first");
      return;
    }
    computeMutation.mutate(
      { datasetId: effectiveDatasetId, minSupport, minConfidence },
      {
        onSuccess: () =>
          toast.success("Association rules computed successfully"),
        onError: () => toast.error("Failed to compute association rules"),
      },
    );
  };

  const handleSort = (key: SortKey) => {
    if (key === sortKey) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir("desc");
    }
  };

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    return rules.filter(
      (r) =>
        !q ||
        r.antecedent.toLowerCase().includes(q) ||
        r.consequent.toLowerCase().includes(q),
    );
  }, [rules, search]);

  const sorted = useMemo(() => {
    return [...filtered].sort((a, b) => {
      let av: string | number;
      let bv: string | number;
      if (sortKey === "antecedent") {
        av = a.antecedent;
        bv = b.antecedent;
      } else if (sortKey === "consequent") {
        av = a.consequent;
        bv = b.consequent;
      } else {
        av = a[sortKey];
        bv = b[sortKey];
      }
      if (typeof av === "string" && typeof bv === "string") {
        return sortDir === "asc" ? av.localeCompare(bv) : bv.localeCompare(av);
      }
      return sortDir === "asc"
        ? (av as number) - (bv as number)
        : (bv as number) - (av as number);
    });
  }, [filtered, sortKey, sortDir]);

  // Summary stats
  const stats = useMemo(() => {
    if (rules.length === 0)
      return { total: 0, avgSupport: 0, avgConfidence: 0, avgLift: 0 };
    const total = rules.length;
    const avgSupport = rules.reduce((s, r) => s + r.support, 0) / total;
    const avgConfidence = rules.reduce((s, r) => s + r.confidence, 0) / total;
    const avgLift = rules.reduce((s, r) => s + r.lift, 0) / total;
    return { total, avgSupport, avgConfidence, avgLift };
  }, [rules]);

  const thClass =
    "px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground select-none cursor-pointer hover:text-foreground transition-colors whitespace-nowrap";

  return (
    <Layout>
      {/* ── Page Header ── */}
      <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">
            Association Rules
          </h1>
          <p className="mt-0.5 text-sm text-muted-foreground">
            Discovered product co-purchase patterns
          </p>
        </div>

        {/* Dataset selector */}
        <div className="flex items-center gap-3">
          <Label className="shrink-0 text-sm text-muted-foreground">
            Dataset
          </Label>
          {datasetsLoading ? (
            <Skeleton className="h-9 w-48" />
          ) : (
            <Select
              value={
                effectiveDatasetId !== null ? effectiveDatasetId.toString() : ""
              }
              onValueChange={(v) => setSelectedDatasetId(BigInt(v))}
            >
              <SelectTrigger
                className="w-52 border-border bg-card"
                data-ocid="rules.dataset_select"
              >
                <SelectValue placeholder="Select dataset…" />
              </SelectTrigger>
              <SelectContent>
                {datasets.length === 0 ? (
                  <SelectItem value="__none" disabled>
                    No datasets uploaded
                  </SelectItem>
                ) : (
                  datasets.map((ds) => (
                    <SelectItem key={ds.id.toString()} value={ds.id.toString()}>
                      {ds.name}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          )}
        </div>
      </div>

      {/* ── Compute Panel ── */}
      <div className="mb-6 rounded-xl border border-border bg-card p-5">
        <h2 className="mb-4 flex items-center gap-2 font-display text-sm font-semibold text-foreground">
          <Zap className="h-4 w-4 text-accent" />
          Compute Rules
        </h2>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-[1fr_1fr_auto]">
          <ControlSlider
            id="rules.min_support"
            label="Min Support"
            min={0.01}
            max={0.5}
            step={0.01}
            value={minSupport}
            onChange={setMinSupport}
            displayValue={fmtPct(minSupport)}
          />
          <ControlSlider
            id="rules.min_confidence"
            label="Min Confidence"
            min={0.1}
            max={1.0}
            step={0.01}
            value={minConfidence}
            onChange={setMinConfidence}
            displayValue={fmtPct(minConfidence)}
          />
          <div className="flex flex-col justify-end gap-2">
            <Button
              data-ocid="rules.compute_button"
              onClick={handleCompute}
              disabled={
                computeMutation.isPending || effectiveDatasetId === null
              }
              className="gap-2 bg-accent text-accent-foreground hover:bg-accent/90"
            >
              {computeMutation.isPending ? (
                <>
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-accent-foreground border-t-transparent" />
                  <span data-ocid="rules.loading_state">Computing…</span>
                </>
              ) : (
                <>
                  <Zap className="h-4 w-4" />
                  Compute Rules
                </>
              )}
            </Button>
            {computeMutation.isSuccess && (
              <div
                data-ocid="rules.success_state"
                className="flex items-center gap-1.5 text-xs text-emerald-400"
              >
                <CheckCircle2 className="h-3.5 w-3.5" />
                Rules computed
              </div>
            )}
            {computeMutation.isError && (
              <div
                data-ocid="rules.error_state"
                className="flex items-center gap-1.5 text-xs text-rose-400"
              >
                <AlertCircle className="h-3.5 w-3.5" />
                Computation failed
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ── Summary Stats ── */}
      <div
        data-ocid="rules.stats_bar"
        className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4"
      >
        <StatCard
          icon={Layers}
          label="Total Rules"
          value={stats.total.toLocaleString()}
        />
        <StatCard
          icon={Percent}
          label="Avg Support"
          value={stats.total ? fmtPct(stats.avgSupport) : "—"}
        />
        <StatCard
          icon={BarChart3}
          label="Avg Confidence"
          value={stats.total ? fmtPct(stats.avgConfidence) : "—"}
        />
        <StatCard
          icon={TrendingUp}
          label="Avg Lift"
          value={stats.total ? fmtLift(stats.avgLift) : "—"}
          sub={stats.total ? getLiftMeta(stats.avgLift).label : undefined}
        />
      </div>

      {/* ── Table Panel ── */}
      <div className="rounded-xl border border-border bg-card overflow-hidden">
        {/* Table toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-4 py-3">
          <h2 className="font-display text-sm font-semibold text-foreground">
            Rules Table{" "}
            {filtered.length > 0 && (
              <span className="ml-1.5 rounded-full bg-accent/10 px-2 py-0.5 text-xs text-accent">
                {filtered.length}
              </span>
            )}
          </h2>
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <Input
              data-ocid="rules.search_input"
              placeholder="Filter by product…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="h-8 w-56 border-border bg-background pl-8 text-sm"
            />
          </div>
        </div>

        {/* Table content */}
        {rulesLoading ? (
          <div className="space-y-0">
            {(["r1", "r2", "r3", "r4", "r5", "r6"] as const).map((k) => (
              <div
                key={k}
                className="flex items-center gap-4 border-b border-border px-4 py-3.5 last:border-0"
              >
                <Skeleton className="h-4 w-36" />
                <Skeleton className="h-4 w-28" />
                <Skeleton className="ml-auto h-4 w-16" />
                <Skeleton className="h-4 w-16" />
                <Skeleton className="h-4 w-16" />
                <Skeleton className="h-5 w-16 rounded-full" />
              </div>
            ))}
          </div>
        ) : rulesError ? (
          <div
            data-ocid="rules.error_state"
            className="flex flex-col items-center justify-center gap-3 py-16 text-center"
          >
            <AlertCircle className="h-10 w-10 text-rose-400/60" />
            <p className="text-sm text-muted-foreground">
              Failed to load association rules
            </p>
          </div>
        ) : sorted.length === 0 ? (
          <div
            data-ocid="rules.empty_state"
            className="flex flex-col items-center justify-center gap-4 py-16 text-center"
          >
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-accent/10">
              <TrendingUp className="h-7 w-7 text-accent" />
            </div>
            <div>
              <p className="font-display font-semibold text-foreground">
                {search
                  ? "No rules match your filter"
                  : "No rules computed yet"}
              </p>
              <p className="mt-1 text-sm text-muted-foreground">
                {search
                  ? "Try a different product name"
                  : "Set your parameters above and click Compute Rules to discover patterns"}
              </p>
            </div>
            {!search && (
              <Button
                data-ocid="rules.empty_compute_button"
                onClick={handleCompute}
                disabled={
                  computeMutation.isPending || effectiveDatasetId === null
                }
                variant="outline"
                className="gap-2 border-accent/30 text-accent hover:bg-accent/10"
              >
                <Zap className="h-4 w-4" />
                Compute Rules Now
              </Button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  {(
                    [
                      {
                        key: "antecedent",
                        label: "If (Antecedent)",
                        align: "",
                      },
                      {
                        key: "consequent",
                        label: "Then (Consequent)",
                        align: "",
                      },
                      {
                        key: "support",
                        label: "Support",
                        align: "text-right justify-end",
                      },
                      {
                        key: "confidence",
                        label: "Confidence",
                        align: "text-right justify-end",
                      },
                      {
                        key: "lift",
                        label: "Lift",
                        align: "text-right justify-end",
                      },
                    ] as { key: SortKey; label: string; align: string }[]
                  ).map(({ key, label, align }) => (
                    <th
                      key={key}
                      className={`${thClass} ${align.includes("text-right") ? "text-right" : ""}`}
                      data-ocid={`rules.${key}_sort`}
                      onClick={() => handleSort(key)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" || e.key === " ") handleSort(key);
                      }}
                    >
                      <span
                        className={`flex items-center ${align.includes("justify-end") ? "justify-end" : ""}`}
                      >
                        {label}
                        <SortIcon
                          col={key}
                          sortKey={sortKey}
                          sortDir={sortDir}
                        />
                      </span>
                    </th>
                  ))}
                  <th className={`${thClass} cursor-default`}>Strength</th>
                </tr>
              </thead>
              <tbody>
                {sorted.map((rule: AssociationRule, idx: number) => {
                  const liftMeta = getLiftMeta(rule.lift);
                  const rowNum = idx + 1;
                  return (
                    <tr
                      key={rule.id.toString()}
                      data-ocid={`rules.item.${rowNum}`}
                      className="border-b border-border/50 transition-colors hover:bg-muted/20 last:border-0 odd:bg-muted/5"
                    >
                      <td className="px-4 py-3 font-medium text-foreground max-w-[220px] truncate">
                        {rule.antecedent}
                      </td>
                      <td className="px-4 py-3 text-muted-foreground max-w-[200px] truncate">
                        {rule.consequent}
                      </td>
                      <td
                        className={`px-4 py-3 text-right font-mono font-medium ${supportColor(rule.support)}`}
                      >
                        {fmtPct(rule.support)}
                      </td>
                      <td
                        className={`px-4 py-3 text-right font-mono font-medium ${confidenceColor(rule.confidence)}`}
                      >
                        {fmtPct(rule.confidence)}
                      </td>
                      <td
                        className={`px-4 py-3 text-right font-mono font-semibold ${liftColor(rule.lift)}`}
                      >
                        {fmtLift(rule.lift)}
                      </td>
                      <td className="px-4 py-3">
                        <Badge
                          variant="outline"
                          className={`inline-flex items-center gap-1.5 text-xs font-medium ${liftMeta.colorClass}`}
                        >
                          <span
                            className={`h-1.5 w-1.5 rounded-full ${liftMeta.dotClass}`}
                          />
                          {liftMeta.label}
                        </Badge>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </Layout>
  );
}
