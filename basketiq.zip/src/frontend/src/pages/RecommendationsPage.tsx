import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertCircle,
  ChevronDown,
  ChevronUp,
  Info,
  Package,
  Search,
  ShoppingCart,
  Sparkles,
  Tag,
  TrendingUp,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Layout } from "../components/Layout";
import {
  useDashboardStats,
  useInventoryItems,
  useRecommendations,
} from "../hooks/useBackend";
import type { InventoryItem, InventoryStatus, Recommendation } from "../types";

// ─── Lift Tier Classification ─────────────────────────────────────────────────
function getLiftTier(lift: number): "high" | "medium" | "low" {
  if (lift >= 2.5) return "high";
  if (lift >= 1.5) return "medium";
  return "low";
}

const LIFT_CARD_STYLES: Record<"high" | "medium" | "low", string> = {
  high: "border-l-4 border-l-accent bg-accent/[0.04]",
  medium: "border-l-4 border-l-accent/50 bg-accent/[0.02]",
  low: "border-l-4 border-l-border",
};

const LIFT_BADGE_STYLES: Record<"high" | "medium" | "low", string> = {
  high: "bg-accent/20 text-accent border-accent/40",
  medium: "bg-accent/10 text-accent/80 border-accent/25",
  low: "bg-muted text-muted-foreground border-border",
};

const ALGO_LABELS: Record<string, string> = {
  apriori: "Apriori",
  collaborative: "Collaborative",
  sequence: "Sequence",
};

// ─── Inventory badge ──────────────────────────────────────────────────────────
function getInventoryStatus(item?: InventoryItem): InventoryStatus {
  if (!item) return "inStock";
  if (!item.isInStock) return "outOfStock";
  if (item.stockLevel <= item.reorderPoint) return "lowStock";
  return "inStock";
}

const INVENTORY_BADGE: Record<
  InventoryStatus,
  { label: string; className: string; dotColor: string }
> = {
  inStock: {
    label: "In Stock",
    className:
      "border-[oklch(0.78_0.17_100/0.4)] text-[oklch(0.78_0.17_100)] bg-[oklch(0.78_0.17_100/0.08)]",
    dotColor: "bg-[oklch(0.78_0.17_100)]",
  },
  lowStock: {
    label: "Low Stock",
    className:
      "border-[oklch(0.68_0.2_50/0.4)] text-[oklch(0.68_0.2_50)] bg-[oklch(0.68_0.2_50/0.08)]",
    dotColor: "bg-[oklch(0.68_0.2_50)]",
  },
  outOfStock: {
    label: "Out of Stock",
    className:
      "border-[oklch(0.65_0.19_22/0.4)] text-[oklch(0.65_0.19_22)] bg-[oklch(0.65_0.19_22/0.08)]",
    dotColor: "bg-[oklch(0.65_0.19_22)]",
  },
};

// ─── Explainability Panel ─────────────────────────────────────────────────────
function ExplainabilityPanel({
  rec,
  searchedProduct,
  algorithm,
}: {
  rec: Recommendation;
  searchedProduct: string;
  algorithm: string;
}) {
  const [open, setOpen] = useState(false);
  const tier = getLiftTier(rec.lift);
  const confidencePct = (rec.confidence * 100).toFixed(1);
  const supportPct = (rec.support * 100).toFixed(2);
  const customerCount = Math.round(rec.support * 1000);

  return (
    <div className="explainability-panel">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="w-full flex items-center justify-between text-xs font-medium text-muted-foreground hover:text-foreground transition-colors"
        data-ocid={`rec.explain_toggle.${rec.product.replace(/\s+/g, "_")}`}
      >
        <span className="flex items-center gap-1.5">
          <Info className="h-3 w-3 text-accent" />
          Why this recommendation?
        </span>
        {open ? (
          <ChevronUp className="h-3 w-3" />
        ) : (
          <ChevronDown className="h-3 w-3" />
        )}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="pt-3 space-y-2.5">
              {/* Rule antecedent → consequent */}
              <div className="flex items-center gap-1.5 bg-muted/30 rounded-md px-3 py-2">
                <span className="text-xs font-mono text-accent font-semibold">
                  {searchedProduct}
                </span>
                <span className="text-xs text-muted-foreground">→</span>
                <span className="text-xs font-mono text-foreground font-semibold">
                  {rec.product}
                </span>
              </div>

              {/* Metrics */}
              <div className="space-y-1.5">
                <div className="rule-metric">
                  <span className="rule-metric-label">Confidence</span>
                  <div className="flex items-center gap-2 flex-1 ml-4">
                    <div className="confidence-bar flex-1 h-1">
                      <div
                        className="confidence-fill"
                        style={{
                          width: `${Math.min(100, Number.parseFloat(confidencePct))}%`,
                        }}
                      />
                    </div>
                    <span className="rule-metric-value">{confidencePct}%</span>
                  </div>
                </div>
                <div className="rule-metric">
                  <span className="rule-metric-label">Lift</span>
                  <span className="rule-metric-value">
                    {rec.lift.toFixed(2)}x{" "}
                    <Badge
                      variant="outline"
                      className={`ml-1 text-xs py-0 px-1.5 ${LIFT_BADGE_STYLES[tier]}`}
                    >
                      {tier}
                    </Badge>
                  </span>
                </div>
                <div className="rule-metric">
                  <span className="rule-metric-label">Support</span>
                  <span className="rule-metric-value">{supportPct}%</span>
                </div>
                <div className="rule-metric">
                  <span className="rule-metric-label">Customers</span>
                  <span className="rule-metric-value">
                    ~{customerCount.toLocaleString()} bought both
                  </span>
                </div>
              </div>

              {/* Source algorithm */}
              <div className="flex items-center gap-1.5 pt-1 border-t border-border/50">
                <span className="text-xs text-muted-foreground">
                  Algorithm:
                </span>
                <Badge
                  variant="outline"
                  className="text-xs py-0 px-2 border-primary/30 text-primary bg-primary/10"
                >
                  {ALGO_LABELS[algorithm] ?? algorithm}
                </Badge>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── Recommendation Card ──────────────────────────────────────────────────────
function RecommendationCard({
  rec,
  index,
  searchedProduct,
  algorithm,
  inventoryItem,
}: {
  rec: Recommendation;
  index: number;
  searchedProduct: string;
  algorithm: string;
  inventoryItem?: InventoryItem;
}) {
  const tier = getLiftTier(rec.lift);
  const isUpsell = rec.lift >= 2.0;
  const liftLabel = `${rec.lift.toFixed(1)}x`;
  const confidencePct = (rec.confidence * 100).toFixed(1);
  const supportPct = (rec.support * 100).toFixed(1);
  const inventoryStatus = getInventoryStatus(inventoryItem);
  const invBadge = INVENTORY_BADGE[inventoryStatus];
  const isOutOfStock = inventoryStatus === "outOfStock";

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, delay: index * 0.06 }}
    >
      <Card
        className={`relative overflow-hidden transition-smooth hover:-translate-y-0.5 hover:shadow-lg ${LIFT_CARD_STYLES[tier]} ${isOutOfStock ? "opacity-50" : ""}`}
        data-ocid={`rec.item.${index + 1}`}
      >
        <CardHeader className="pb-2 pt-4 px-4">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <ShoppingCart className="h-4 w-4 text-accent shrink-0 mt-0.5" />
              <p className="font-semibold text-foreground truncate text-sm leading-snug">
                {rec.product}
              </p>
            </div>
            <Badge
              variant="outline"
              className={`shrink-0 text-xs font-mono font-bold px-2 py-0.5 ${LIFT_BADGE_STYLES[tier]}`}
            >
              Lift: {liftLabel}
            </Badge>
          </div>

          {/* Inventory badge */}
          <div className="mt-1.5">
            <span
              className={`inline-flex items-center gap-1.5 text-xs px-2 py-0.5 rounded-full border ${invBadge.className}`}
              data-ocid={`rec.inventory_badge.${index + 1}`}
            >
              <span
                className={`h-1.5 w-1.5 rounded-full ${invBadge.dotColor}`}
              />
              {invBadge.label}
              {inventoryItem && inventoryStatus !== "outOfStock" && (
                <span className="opacity-70">
                  ({inventoryItem.stockLevel} units)
                </span>
              )}
            </span>
          </div>
        </CardHeader>

        <CardContent className="px-4 pb-4 space-y-3">
          {/* Metrics row */}
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-muted/40 rounded-md px-3 py-2">
              <p className="metric-label mb-0.5">Confidence</p>
              <p className="text-base font-semibold text-foreground">
                {confidencePct}%
              </p>
              <div className="mt-1.5 h-1 w-full rounded-full bg-border overflow-hidden">
                <div
                  className="h-full rounded-full bg-accent transition-all duration-700"
                  style={{
                    width: `${Math.min(100, Number.parseFloat(confidencePct))}%`,
                  }}
                />
              </div>
            </div>
            <div className="bg-muted/40 rounded-md px-3 py-2">
              <p className="metric-label mb-0.5">Support</p>
              <p className="text-base font-semibold text-foreground">
                {supportPct}%
              </p>
              <div className="mt-1.5 h-1 w-full rounded-full bg-border overflow-hidden">
                <div
                  className="h-full rounded-full bg-primary/80 transition-all duration-700"
                  style={{
                    width: `${Math.min(100, Number.parseFloat(supportPct) * 4)}%`,
                  }}
                />
              </div>
            </div>
          </div>

          {/* Opportunity label */}
          <div className="flex items-center gap-1.5">
            <Tag className="h-3.5 w-3.5 text-muted-foreground" />
            <span className="text-xs text-muted-foreground font-medium">
              {isUpsell ? "Upsell opportunity" : "Cross-sell opportunity"}
            </span>
            {tier === "high" && (
              <Sparkles className="h-3 w-3 text-accent ml-auto" />
            )}
          </div>

          {/* Explainability panel */}
          <ExplainabilityPanel
            rec={rec}
            searchedProduct={searchedProduct}
            algorithm={algorithm}
          />
        </CardContent>
      </Card>
    </motion.div>
  );
}

// ─── Skeleton Cards ───────────────────────────────────────────────────────────
function RecommendationSkeleton() {
  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-2 pt-4 px-4">
        <div className="flex items-start justify-between gap-2">
          <Skeleton className="h-4 w-40" />
          <Skeleton className="h-5 w-16 rounded-full" />
        </div>
        <Skeleton className="h-5 w-24 rounded-full mt-2" />
      </CardHeader>
      <CardContent className="px-4 pb-4 space-y-3">
        <div className="grid grid-cols-2 gap-2">
          <Skeleton className="h-16 rounded-md" />
          <Skeleton className="h-16 rounded-md" />
        </div>
        <Skeleton className="h-4 w-32" />
        <Skeleton className="h-8 rounded-md" />
      </CardContent>
    </Card>
  );
}

// ─── Search Suggestions Dropdown ─────────────────────────────────────────────
function SearchSuggestions({
  suggestions,
  onSelect,
}: {
  suggestions: string[];
  onSelect: (p: string) => void;
}) {
  if (suggestions.length === 0) return null;
  return (
    <motion.ul
      initial={{ opacity: 0, y: -4 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -4 }}
      className="absolute z-50 top-full left-0 right-0 mt-1 bg-popover border border-border rounded-lg shadow-xl overflow-hidden"
      data-ocid="rec.search_suggestions"
    >
      {suggestions.map((s, i) => (
        <li key={s}>
          <button
            type="button"
            className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-foreground hover:bg-accent/10 transition-colors text-left"
            onClick={() => onSelect(s)}
            data-ocid={`rec.suggestion.${i + 1}`}
          >
            <Search className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
            {s}
          </button>
        </li>
      ))}
    </motion.ul>
  );
}

// ─── Sort / Filter Controls ───────────────────────────────────────────────────
type SortKey = "lift" | "confidence" | "support" | "inventory";
type SegmentFilter = "all" | "champions" | "loyal" | "atRisk";
type AlgorithmTab = "apriori" | "collaborative" | "sequence";

const SORT_OPTIONS: { key: SortKey; label: string }[] = [
  { key: "lift", label: "Lift" },
  { key: "confidence", label: "Confidence" },
  { key: "support", label: "Support" },
  { key: "inventory", label: "Inventory Priority" },
];

const SEGMENT_OPTIONS: { key: SegmentFilter; label: string }[] = [
  { key: "all", label: "All" },
  { key: "champions", label: "Champions" },
  { key: "loyal", label: "Loyal" },
  { key: "atRisk", label: "At-Risk" },
];

const ALGORITHM_TABS: { key: AlgorithmTab; label: string }[] = [
  { key: "apriori", label: "Apriori" },
  { key: "collaborative", label: "Collaborative" },
  { key: "sequence", label: "Sequence" },
];

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function RecommendationsPage() {
  const [inputValue, setInputValue] = useState("");
  const [searchedProduct, setSearchedProduct] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [algorithm, setAlgorithm] = useState<AlgorithmTab>("apriori");
  const [sortBy, setSortBy] = useState<SortKey>("lift");
  const [segment, setSegment] = useState<SegmentFilter>("all");
  const inputRef = useRef<HTMLInputElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);

  const { data: stats } = useDashboardStats();
  const { data: inventoryItems = [] } = useInventoryItems();

  const popularProducts = useMemo<string[]>(
    () => stats?.topProducts ?? [],
    [stats],
  );

  // Inventory lookup map by product name
  const inventoryMap = useMemo(() => {
    const map = new Map<string, InventoryItem>();
    for (const item of inventoryItems) {
      map.set(item.productName.toLowerCase(), item);
    }
    return map;
  }, [inventoryItems]);

  const suggestions = useMemo(() => {
    if (!inputValue.trim() || inputValue.length < 2) return [];
    const lower = inputValue.toLowerCase();
    return popularProducts
      .filter((p) => p.toLowerCase().includes(lower))
      .slice(0, 6);
  }, [inputValue, popularProducts]);

  const {
    data: recommendations = [],
    isLoading,
    isFetching,
  } = useRecommendations(searchedProduct, BigInt(12));

  // Sort recommendations
  const sortedRecs = useMemo(() => {
    const recs = [...recommendations];
    switch (sortBy) {
      case "lift":
        return recs.sort((a, b) => b.lift - a.lift);
      case "confidence":
        return recs.sort((a, b) => b.confidence - a.confidence);
      case "support":
        return recs.sort((a, b) => b.support - a.support);
      case "inventory": {
        return recs.sort((a, b) => {
          const aItem = inventoryMap.get(a.product.toLowerCase());
          const bItem = inventoryMap.get(b.product.toLowerCase());
          const aStatus = getInventoryStatus(aItem);
          const bStatus = getInventoryStatus(bItem);
          const priority = { inStock: 0, lowStock: 1, outOfStock: 2 };
          return priority[aStatus] - priority[bStatus];
        });
      }
    }
  }, [recommendations, sortBy, inventoryMap]);

  const handleSearch = useCallback(() => {
    const trimmed = inputValue.trim();
    if (!trimmed) return;
    setSearchedProduct(trimmed);
    setShowSuggestions(false);
  }, [inputValue]);

  const handleSelectSuggestion = useCallback((product: string) => {
    setInputValue(product);
    setSearchedProduct(product);
    setShowSuggestions(false);
  }, []);

  const handleChipClick = useCallback((product: string) => {
    setInputValue(product);
    setSearchedProduct(product);
    setShowSuggestions(false);
  }, []);

  // Close suggestions on outside click
  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (
        wrapperRef.current &&
        !wrapperRef.current.contains(e.target as Node)
      ) {
        setShowSuggestions(false);
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  const loadingRecs = (isLoading || isFetching) && searchedProduct.length > 0;
  const isEmpty =
    !loadingRecs && searchedProduct.length > 0 && sortedRecs.length === 0;
  const hasResults = !loadingRecs && sortedRecs.length > 0;

  return (
    <Layout title="Product Recommendations">
      <div className="max-w-6xl mx-auto space-y-6" data-ocid="rec.page">
        {/* ── Page Header ── */}
        <motion.div
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="flex items-start justify-between gap-4 flex-wrap"
        >
          <div>
            <p className="text-sm text-muted-foreground mt-0.5">
              Cross-sell and upsell opportunities powered by association rules
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground bg-card border border-border rounded-lg px-3 py-2">
            <TrendingUp className="h-3.5 w-3.5 text-accent" />
            <span>
              {popularProducts.length > 0
                ? `${popularProducts.length} products indexed`
                : "No products yet"}
            </span>
          </div>
        </motion.div>

        {/* ── Algorithm Selector Tabs ── */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.05 }}
          className="flex items-center gap-1 bg-muted/50 border border-border rounded-lg p-1 w-fit"
          data-ocid="rec.algorithm_tabs"
        >
          {ALGORITHM_TABS.map((tab) => (
            <button
              key={tab.key}
              type="button"
              onClick={() => setAlgorithm(tab.key)}
              className={[
                "px-4 py-1.5 rounded-md text-sm font-medium transition-smooth",
                algorithm === tab.key
                  ? "bg-card border border-border text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground",
              ].join(" ")}
              data-ocid={`rec.algorithm_tab.${tab.key}`}
            >
              {tab.label}
            </button>
          ))}
        </motion.div>

        {/* ── Search Section ── */}
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.08 }}
          className="bg-card border border-border rounded-xl p-6"
          data-ocid="rec.search_section"
        >
          <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
            <div>
              <h2 className="text-base font-semibold text-foreground mb-1">
                Find Recommendations
              </h2>
              <p className="text-sm text-muted-foreground">
                Search for a product to discover what customers frequently buy
                together with it.
              </p>
            </div>

            {/* Segment filter */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs text-muted-foreground">Segment:</span>
              <div className="flex gap-1">
                {SEGMENT_OPTIONS.map((opt) => (
                  <button
                    key={opt.key}
                    type="button"
                    onClick={() => setSegment(opt.key)}
                    className={[
                      "px-2.5 py-1 rounded-md text-xs font-medium transition-smooth",
                      segment === opt.key
                        ? "bg-primary/20 border border-primary/30 text-primary"
                        : "bg-muted/40 border border-border text-muted-foreground hover:text-foreground",
                    ].join(" ")}
                    data-ocid={`rec.segment_filter.${opt.key}`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="flex gap-3 items-start">
            <div className="relative flex-1" ref={wrapperRef}>
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none z-10" />
              <Input
                ref={inputRef}
                placeholder="Enter a product name..."
                value={inputValue}
                onChange={(e) => {
                  setInputValue(e.target.value);
                  setShowSuggestions(true);
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleSearch();
                  if (e.key === "Escape") setShowSuggestions(false);
                }}
                onFocus={() => setShowSuggestions(true)}
                className="pl-10 h-11 bg-background border-input text-foreground placeholder:text-muted-foreground"
                data-ocid="rec.search_input"
              />
              <AnimatePresence>
                {showSuggestions && suggestions.length > 0 && (
                  <SearchSuggestions
                    suggestions={suggestions}
                    onSelect={handleSelectSuggestion}
                  />
                )}
              </AnimatePresence>
            </div>
            <Button
              onClick={handleSearch}
              disabled={!inputValue.trim()}
              className="h-11 px-6 bg-accent text-accent-foreground hover:bg-accent/90 shrink-0"
              data-ocid="rec.search_button"
            >
              <Search className="h-4 w-4 mr-2" />
              Search
            </Button>
          </div>
        </motion.section>

        {/* ── Popular Products Quick-Select ── */}
        {popularProducts.length > 0 && (
          <motion.section
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.14 }}
            data-ocid="rec.popular_section"
          >
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">
              Popular Products
            </h2>
            <div className="flex flex-wrap gap-2">
              {popularProducts.map((product, i) => (
                <button
                  key={product}
                  type="button"
                  onClick={() => handleChipClick(product)}
                  className={[
                    "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium",
                    "border transition-smooth cursor-pointer",
                    searchedProduct === product
                      ? "bg-accent/20 border-accent/50 text-accent"
                      : "bg-muted/50 border-border text-muted-foreground hover:bg-accent/10 hover:border-accent/30 hover:text-foreground",
                  ].join(" ")}
                  data-ocid={`rec.chip.${i + 1}`}
                >
                  <ShoppingCart className="h-3 w-3" />
                  {product}
                </button>
              ))}
            </div>
          </motion.section>
        )}

        {/* ── Sort Controls (only when results are present) ── */}
        {hasResults && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-center gap-3 flex-wrap"
            data-ocid="rec.sort_controls"
          >
            <span className="text-xs text-muted-foreground">Sort by:</span>
            {SORT_OPTIONS.map((opt) => (
              <button
                key={opt.key}
                type="button"
                onClick={() => setSortBy(opt.key)}
                className={[
                  "px-3 py-1 rounded-md text-xs font-medium border transition-smooth",
                  sortBy === opt.key
                    ? "bg-accent/15 border-accent/35 text-accent"
                    : "bg-muted/30 border-border text-muted-foreground hover:text-foreground",
                ].join(" ")}
                data-ocid={`rec.sort.${opt.key}`}
              >
                {opt.label}
              </button>
            ))}

            {/* Inventory legend */}
            <div className="ml-auto hidden sm:flex items-center gap-3 text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <Package className="h-3.5 w-3.5 text-[oklch(0.78_0.17_100)]" />
                In Stock
              </span>
              <span className="flex items-center gap-1.5">
                <Package className="h-3.5 w-3.5 text-[oklch(0.68_0.2_50)]" />
                Low Stock
              </span>
              <span className="flex items-center gap-1.5">
                <Package className="h-3.5 w-3.5 text-[oklch(0.65_0.19_22)]" />
                Out of Stock
              </span>
            </div>
          </motion.div>
        )}

        {/* ── Results Section ── */}
        <AnimatePresence mode="wait">
          {/* Loading Skeletons */}
          {loadingRecs && (
            <motion.section
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              data-ocid="rec.loading_state"
            >
              <Skeleton className="h-5 w-52 mb-4" />
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  // biome-ignore lint/suspicious/noArrayIndexKey: skeleton placeholders have no identity
                  <RecommendationSkeleton key={i} />
                ))}
              </div>
            </motion.section>
          )}

          {/* Empty State */}
          {isEmpty && (
            <motion.section
              key="empty"
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-20 text-center"
              data-ocid="rec.empty_state"
            >
              <div className="h-16 w-16 rounded-2xl bg-muted/60 flex items-center justify-center mb-4">
                <AlertCircle className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="text-base font-semibold text-foreground mb-1">
                No recommendations found for &ldquo;{searchedProduct}&rdquo;
              </h3>
              <p className="text-sm text-muted-foreground max-w-sm">
                This product may not have enough association rules yet. Try
                uploading a dataset and computing rules on the{" "}
                <a
                  href="/upload"
                  className="text-accent underline underline-offset-2"
                >
                  Upload
                </a>{" "}
                page first, then return here to explore recommendations.
              </p>
            </motion.section>
          )}

          {/* Results Grid */}
          {hasResults && (
            <motion.section
              key="results"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              data-ocid="rec.results_section"
            >
              <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                <h2 className="text-base font-semibold text-foreground">
                  Recommendations for{" "}
                  <span className="text-accent">{searchedProduct}</span>
                  {segment !== "all" && (
                    <span className="text-muted-foreground text-sm font-normal ml-1.5">
                      · {SEGMENT_OPTIONS.find((s) => s.key === segment)?.label}{" "}
                      segment
                    </span>
                  )}
                </h2>
                <div className="flex items-center gap-3">
                  {/* Lift legend */}
                  <div className="hidden sm:flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1.5">
                      <span className="inline-block w-2.5 h-2.5 rounded-sm bg-accent" />
                      High ≥ 2.5x
                    </span>
                    <span className="flex items-center gap-1.5">
                      <span className="inline-block w-2.5 h-2.5 rounded-sm bg-accent/50" />
                      Medium ≥ 1.5x
                    </span>
                    <span className="flex items-center gap-1.5">
                      <span className="inline-block w-2.5 h-2.5 rounded-sm bg-border" />
                      Low
                    </span>
                  </div>
                  <Badge
                    variant="outline"
                    className="text-xs text-muted-foreground border-border font-mono"
                    data-ocid="rec.results_count"
                  >
                    {sortedRecs.length} result
                    {sortedRecs.length !== 1 ? "s" : ""}
                  </Badge>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {sortedRecs.map((rec, i) => (
                  <RecommendationCard
                    key={`${rec.product}-${algorithm}`}
                    rec={rec}
                    index={i}
                    searchedProduct={searchedProduct}
                    algorithm={algorithm}
                    inventoryItem={inventoryMap.get(rec.product.toLowerCase())}
                  />
                ))}
              </div>
            </motion.section>
          )}

          {/* Initial call-to-action state */}
          {!searchedProduct && !loadingRecs && (
            <motion.section
              key="initial"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-20 text-center"
              data-ocid="rec.initial_state"
            >
              <div className="h-16 w-16 rounded-2xl bg-accent/10 flex items-center justify-center mb-4">
                <Sparkles className="h-8 w-8 text-accent" />
              </div>
              <h3 className="text-base font-semibold text-foreground mb-1">
                Discover Product Associations
              </h3>
              <p className="text-sm text-muted-foreground max-w-sm">
                Search for any product above, or click a popular product chip to
                instantly surface cross-sell and upsell recommendations driven
                by purchase patterns.
              </p>
            </motion.section>
          )}
        </AnimatePresence>
      </div>
    </Layout>
  );
}
