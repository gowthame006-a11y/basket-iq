import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Activity,
  AlertTriangle,
  Database,
  Info,
  Package,
  RefreshCw,
  ShoppingCart,
  TrendingUp,
  XCircle,
} from "lucide-react";
import { useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Tooltip as RechartTooltip,
  ResponsiveContainer,
  Scatter,
  ScatterChart,
  XAxis,
  YAxis,
  ZAxis,
} from "recharts";
import { toast } from "sonner";
import { Layout } from "../components/Layout";
import { useAuth } from "../hooks/useAuth";
import {
  useAlertStats,
  useAlerts,
  useAllAssociationRules,
  useDashboardStats,
  useDismissAlert,
  useGenerateAlerts,
  useGenerateSyntheticTransaction,
  useStreamingStatus,
  useToggleStreamingMode,
  useTopProductPairs,
} from "../hooks/useBackend";
import type { Alert, AssociationRule } from "../types";
import { AlertsPanel } from "./dashboard/AlertsPanel";
import { StreamingPanel } from "./dashboard/StreamingPanel";

// ─── Helpers ─────────────────────────────────────────────────────────────────

function formatBig(n: bigint | undefined): string {
  return n !== undefined ? Number(n).toLocaleString() : "—";
}

function liftTier(lift: number): string {
  if (lift >= 2.5) return "strong";
  if (lift >= 1.5) return "good";
  return "moderate";
}

function liftColor(lift: number): string {
  if (lift >= 2.5) return "oklch(0.68 0.2 187)"; // teal = strong
  if (lift >= 1.5) return "oklch(0.62 0.2 264)"; // blue = good
  return "oklch(0.45 0.05 264)"; // slate = moderate
}

function liftBadgeClass(lift: number): string {
  if (lift >= 2.5)
    return "bg-[oklch(0.68_0.2_187/0.15)] text-[oklch(0.68_0.2_187)] border-[oklch(0.68_0.2_187/0.3)]";
  if (lift >= 1.5)
    return "bg-[oklch(0.62_0.2_264/0.15)] text-primary border-primary/30";
  return "bg-muted text-muted-foreground border-border";
}

// ─── KPI Stat Card ────────────────────────────────────────────────────────────

interface StatCardProps {
  label: string;
  value: string | number;
  icon: React.ReactNode;
  subtext?: string;
  variant?: "default" | "accent" | "warning";
  ocid: string;
  loading?: boolean;
}

function StatCard({
  label,
  value,
  icon,
  subtext,
  variant = "default",
  ocid,
  loading,
}: StatCardProps) {
  const iconBg =
    variant === "accent"
      ? "bg-accent/15 text-accent"
      : variant === "warning"
        ? "bg-[oklch(0.68_0.2_50/0.15)] text-[oklch(0.68_0.2_50)]"
        : "bg-muted text-muted-foreground";

  const valClass =
    variant === "accent"
      ? "metric-value text-accent"
      : variant === "warning"
        ? "metric-value text-[oklch(0.68_0.2_50)]"
        : "metric-value";

  return (
    <Card
      className="border-border bg-card transition-smooth hover:border-accent/30"
      data-ocid={ocid}
    >
      <CardContent className="flex items-start justify-between p-5 gap-3">
        <div className="space-y-1 min-w-0">
          <p className="metric-label">{label}</p>
          {loading ? (
            <>
              <Skeleton className="h-7 w-20 mb-1" />
              <Skeleton className="h-3 w-14" />
            </>
          ) : (
            <>
              <p className={valClass}>{value}</p>
              {subtext && (
                <p className="text-[11px] text-muted-foreground/70">
                  {subtext}
                </p>
              )}
            </>
          )}
        </div>
        <div className={`rounded-lg p-2.5 shrink-0 ${iconBg}`}>{icon}</div>
      </CardContent>
    </Card>
  );
}

// ─── Chart Tooltips ───────────────────────────────────────────────────────────

interface BarTooltipProps {
  active?: boolean;
  payload?: Array<{ value: number }>;
  label?: string;
}

function BarTooltip({ active, payload, label }: BarTooltipProps) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded border border-border bg-popover px-3 py-2 shadow-lg">
      <p className="text-[10px] text-muted-foreground mb-0.5 truncate max-w-[180px]">
        {label}
      </p>
      <p className="text-xs font-semibold text-accent">
        Support: {(payload[0].value * 100).toFixed(2)}%
      </p>
    </div>
  );
}

interface ScatterTooltipProps {
  active?: boolean;
  payload?: Array<{ payload: AssociationRule }>;
}

function ScatterTooltip({ active, payload }: ScatterTooltipProps) {
  if (!active || !payload?.length) return null;
  const rule = payload[0].payload;
  return (
    <div className="rounded border border-border bg-popover px-3 py-2.5 shadow-lg max-w-[220px]">
      <p className="text-xs font-semibold text-foreground mb-1 break-words">
        {rule.antecedent} → {rule.consequent}
      </p>
      <div className="grid grid-cols-2 gap-x-4 gap-y-0.5 text-[11px]">
        <span className="text-muted-foreground">Support</span>
        <span className="text-right text-foreground font-mono">
          {(rule.support * 100).toFixed(2)}%
        </span>
        <span className="text-muted-foreground">Confidence</span>
        <span className="text-right text-foreground font-mono">
          {(rule.confidence * 100).toFixed(1)}%
        </span>
        <span className="text-muted-foreground">Lift</span>
        <span
          className="text-right font-semibold font-mono"
          style={{ color: liftColor(rule.lift) }}
        >
          {rule.lift.toFixed(2)}×
        </span>
        <span className="text-muted-foreground">Tier</span>
        <span className="text-right capitalize text-foreground">
          {liftTier(rule.lift)}
        </span>
      </div>
    </div>
  );
}

// ─── Charts Row ───────────────────────────────────────────────────────────────

function ChartsRow() {
  const { data: pairs, isLoading: pairsLoading } = useTopProductPairs(
    BigInt(10),
  );
  const { data: rules, isLoading: rulesLoading } = useAllAssociationRules();

  const barData = (pairs ?? []).slice(0, 10).map((p) => ({
    label: `${p.productA} + ${p.productB}`,
    support: p.support,
  }));

  const scatterData = (rules ?? []).map((r) => ({
    ...r,
    x: r.support,
    y: r.confidence,
    z: Math.max(r.lift, 0.5),
  }));

  const chartGridColor = "oklch(0.24 0 0)";
  const tickColor = "oklch(0.55 0 0)";

  return (
    <section
      className="grid grid-cols-1 gap-4 xl:grid-cols-2"
      data-ocid="dashboard.charts.section"
    >
      {/* Bar: Top Product Pairs */}
      <Card
        className="border-border bg-card"
        data-ocid="dashboard.pairs_chart.card"
      >
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-foreground">
            Top Product Pairs by Support
          </CardTitle>
          <p className="text-xs text-muted-foreground">
            Co-occurrence frequency, sorted descending
          </p>
        </CardHeader>
        <CardContent>
          {pairsLoading ? (
            <div className="h-64 flex items-center justify-center">
              <div className="h-5 w-5 animate-spin rounded-full border-2 border-accent border-t-transparent" />
            </div>
          ) : barData.length === 0 ? (
            <div
              className="h-64 flex flex-col items-center justify-center gap-2 text-muted-foreground"
              data-ocid="dashboard.pairs_chart.empty_state"
            >
              <TrendingUp className="h-8 w-8 opacity-25" />
              <p className="text-sm">No product pair data yet</p>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={270}>
              <BarChart
                data={barData}
                layout="vertical"
                margin={{ top: 4, right: 24, bottom: 4, left: 8 }}
              >
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke={chartGridColor}
                  horizontal={false}
                />
                <XAxis
                  type="number"
                  domain={[0, "dataMax"]}
                  tickFormatter={(v: number) => `${(v * 100).toFixed(0)}%`}
                  tick={{
                    fontSize: 10,
                    fill: tickColor,
                    fontFamily: "var(--font-mono)",
                  }}
                  tickLine={false}
                  axisLine={{ stroke: chartGridColor }}
                />
                <YAxis
                  type="category"
                  dataKey="label"
                  width={136}
                  tick={{ fontSize: 9, fill: tickColor }}
                  tickLine={false}
                  axisLine={false}
                />
                <RechartTooltip
                  content={<BarTooltip />}
                  cursor={{ fill: "oklch(0.2 0 0)" }}
                />
                <Bar
                  dataKey="support"
                  radius={[0, 3, 3, 0]}
                  fill="oklch(0.68 0.2 187)"
                  maxBarSize={18}
                />
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      {/* Scatter: Support vs Confidence */}
      <Card
        className="border-border bg-card"
        data-ocid="dashboard.scatter_chart.card"
      >
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-foreground">
            Support vs Confidence
          </CardTitle>
          <div className="flex flex-wrap items-center gap-3 text-[10px] text-muted-foreground mt-0.5">
            <span>Bubble size = lift</span>
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-accent inline-block" />
              Strong (≥2.5×)
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-primary inline-block" />
              Good (≥1.5×)
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-muted inline-block" />
              Moderate
            </span>
          </div>
        </CardHeader>
        <CardContent>
          {rulesLoading ? (
            <div className="h-64 flex items-center justify-center">
              <div className="h-5 w-5 animate-spin rounded-full border-2 border-accent border-t-transparent" />
            </div>
          ) : scatterData.length === 0 ? (
            <div
              className="h-64 flex flex-col items-center justify-center gap-2 text-muted-foreground"
              data-ocid="dashboard.scatter_chart.empty_state"
            >
              <Activity className="h-8 w-8 opacity-25" />
              <p className="text-sm">Compute rules to visualize patterns</p>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={270}>
              <ScatterChart margin={{ top: 8, right: 20, bottom: 24, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={chartGridColor} />
                <XAxis
                  type="number"
                  dataKey="x"
                  name="Support"
                  tickFormatter={(v: number) => `${(v * 100).toFixed(0)}%`}
                  label={{
                    value: "Support",
                    position: "insideBottom",
                    offset: -14,
                    fontSize: 10,
                    fill: tickColor,
                  }}
                  tick={{
                    fontSize: 10,
                    fill: tickColor,
                    fontFamily: "var(--font-mono)",
                  }}
                  tickLine={false}
                  axisLine={{ stroke: chartGridColor }}
                />
                <YAxis
                  type="number"
                  dataKey="y"
                  name="Confidence"
                  tickFormatter={(v: number) => `${(v * 100).toFixed(0)}%`}
                  label={{
                    value: "Confidence",
                    angle: -90,
                    position: "insideLeft",
                    offset: 10,
                    fontSize: 10,
                    fill: tickColor,
                  }}
                  tick={{
                    fontSize: 10,
                    fill: tickColor,
                    fontFamily: "var(--font-mono)",
                  }}
                  tickLine={false}
                  axisLine={{ stroke: chartGridColor }}
                />
                <ZAxis type="number" dataKey="z" range={[40, 200]} />
                <RechartTooltip
                  content={<ScatterTooltip />}
                  cursor={{ strokeDasharray: "3 3", stroke: tickColor }}
                />
                <Scatter data={scatterData} fillOpacity={0.8}>
                  {scatterData.map((entry, idx) => (
                    <Cell
                      key={`sc-${entry.antecedent}-${entry.consequent}-${idx}`}
                      fill={liftColor(entry.z)}
                    />
                  ))}
                </Scatter>
              </ScatterChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>
    </section>
  );
}

// ─── Top Rules Table ──────────────────────────────────────────────────────────

function TopRulesTable() {
  const { data: rules, isLoading } = useAllAssociationRules();

  const sorted = [...(rules ?? [])]
    .sort((a, b) => b.lift - a.lift)
    .slice(0, 10);

  return (
    <section data-ocid="dashboard.rules_table.section">
      <Card
        className="border-border bg-card"
        data-ocid="dashboard.rules_table.card"
      >
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-sm font-semibold text-foreground">
                Top Association Rules
              </CardTitle>
              <p className="text-xs text-muted-foreground mt-0.5">
                Top 10 by lift score — antecedent → consequent
              </p>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="space-y-px px-4 pb-4">
              {["r1", "r2", "r3", "r4", "r5"].map((k) => (
                <Skeleton
                  key={k}
                  className="h-9 w-full rounded-none first:rounded-t last:rounded-b"
                />
              ))}
            </div>
          ) : sorted.length === 0 ? (
            <div
              className="flex flex-col items-center justify-center h-36 gap-2 text-muted-foreground"
              data-ocid="dashboard.rules_table.empty_state"
            >
              <TrendingUp className="h-8 w-8 opacity-20" />
              <p className="text-sm">No association rules generated yet</p>
              <p className="text-xs opacity-60">
                Upload a dataset and compute rules to see them here
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table
                className="w-full text-xs"
                data-ocid="dashboard.rules_table.table"
              >
                <thead>
                  <tr className="border-b border-border bg-muted/20">
                    <th className="text-left px-4 py-2.5 text-[10px] uppercase tracking-wider text-muted-foreground font-semibold w-6">
                      #
                    </th>
                    <th className="text-left px-4 py-2.5 text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">
                      Antecedent → Consequent
                    </th>
                    <th className="text-right px-4 py-2.5 text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">
                      Support
                    </th>
                    <th className="text-right px-4 py-2.5 text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">
                      Confidence
                    </th>
                    <th className="text-right px-4 py-2.5 text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">
                      Lift
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {sorted.map((rule, i) => (
                    <tr
                      key={rule.id.toString()}
                      className="border-b border-border/40 hover:bg-muted/20 transition-colors group"
                      data-ocid={`dashboard.rules_table.item.${i + 1}`}
                    >
                      <td className="px-4 py-2.5 text-muted-foreground font-mono">
                        {i + 1}
                      </td>
                      <td className="px-4 py-2.5 max-w-[280px]">
                        <span className="text-accent font-medium">
                          {rule.antecedent}
                        </span>
                        <span className="text-muted-foreground mx-2">→</span>
                        <span className="text-foreground">
                          {rule.consequent}
                        </span>
                      </td>
                      <td className="px-4 py-2.5 text-right font-mono text-muted-foreground">
                        {(rule.support * 100).toFixed(2)}%
                      </td>
                      <td className="px-4 py-2.5 text-right font-mono text-muted-foreground">
                        {(rule.confidence * 100).toFixed(1)}%
                      </td>
                      <td className="px-4 py-2.5 text-right">
                        <span
                          className={`inline-flex items-center px-1.5 py-0.5 rounded-sm text-[10px] font-semibold border font-mono ${liftBadgeClass(rule.lift)}`}
                        >
                          {rule.lift.toFixed(2)}×
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </section>
  );
}

// ─── Main DashboardPage ───────────────────────────────────────────────────────

export default function DashboardPage() {
  const { isAdmin } = useAuth();
  const {
    data: stats,
    isLoading: statsLoading,
    dataUpdatedAt,
  } = useDashboardStats();

  const lastComputed = dataUpdatedAt
    ? new Date(dataUpdatedAt).toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      })
    : null;

  return (
    <Layout
      title="Market Intelligence Dashboard"
      actions={
        <div className="flex items-center gap-2.5">
          {lastComputed && (
            <span className="text-[11px] text-muted-foreground hidden sm:inline">
              Updated {lastComputed}
            </span>
          )}
          <Badge
            variant="outline"
            className="border-accent/40 text-accent text-[11px] px-2 py-0.5 gap-1.5"
            data-ocid="dashboard.polling.badge"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-accent animate-pulse" />
            Auto-refresh 30s
          </Badge>
        </div>
      }
    >
      <div className="space-y-5 pb-8" data-ocid="dashboard.page">
        {/* ── KPI Row (5 cards) ───────────────────────────────────── */}
        <section
          className="grid grid-cols-2 gap-3 lg:grid-cols-5"
          data-ocid="dashboard.kpi.section"
        >
          <StatCard
            label="Total Datasets"
            value={formatBig(stats?.totalDatasets)}
            icon={<Database className="h-4 w-4" />}
            subtext="uploaded sources"
            loading={statsLoading}
            ocid="dashboard.kpi.total_datasets.card"
          />
          <StatCard
            label="Total Transactions"
            value={formatBig(stats?.totalTransactions)}
            icon={<ShoppingCart className="h-4 w-4" />}
            subtext="across all datasets"
            loading={statsLoading}
            ocid="dashboard.kpi.total_transactions.card"
          />
          <StatCard
            label="Active Rules"
            value={formatBig(stats?.totalRules)}
            icon={<TrendingUp className="h-4 w-4" />}
            subtext="association rules"
            variant="accent"
            loading={statsLoading}
            ocid="dashboard.kpi.active_rules.card"
          />
          <StatCard
            label="Products Tracked"
            value={formatBig(stats?.totalProducts)}
            icon={<Package className="h-4 w-4" />}
            subtext="unique SKUs"
            loading={statsLoading}
            ocid="dashboard.kpi.products_tracked.card"
          />
          <StatCard
            label="Avg Lift Score"
            value={stats?.avgLift != null ? stats.avgLift.toFixed(3) : "—"}
            icon={<Activity className="h-4 w-4" />}
            subtext=">1.0 = positive signal"
            variant={
              stats?.avgLift != null && stats.avgLift > 1.5
                ? "accent"
                : "default"
            }
            loading={statsLoading}
            ocid="dashboard.kpi.avg_lift.card"
          />
        </section>

        {/* ── Alerts Panel ────────────────────────────────────────── */}
        <AlertsPanel isAdmin={isAdmin} />

        {/* ── Charts Row ──────────────────────────────────────────── */}
        <ChartsRow />

        {/* ── Streaming Panel (admin only) ────────────────────────── */}
        {isAdmin && <StreamingPanel />}

        {/* ── Top Rules Table ─────────────────────────────────────── */}
        <TopRulesTable />
      </div>
    </Layout>
  );
}
