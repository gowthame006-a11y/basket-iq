import {
  Navigate,
  RouterProvider,
  createRootRoute,
  createRoute,
  createRouter,
} from "@tanstack/react-router";
import { Suspense, lazy } from "react";
import { ProtectedRoute } from "./components/ProtectedRoute";

// Lazy-loaded pages
const LoginPage = lazy(() => import("./pages/LoginPage"));
const DashboardPage = lazy(() => import("./pages/DashboardPage"));
const RulesPage = lazy(() => import("./pages/RulesPage"));
const RecommendationsPage = lazy(() => import("./pages/RecommendationsPage"));
const UploadPage = lazy(() => import("./pages/UploadPage"));
const SettingsPage = lazy(() => import("./pages/SettingsPage"));
const AnalyticsPage = lazy(() => import("./pages/AnalyticsPage"));
const NetworkGraphPage = lazy(() => import("./pages/NetworkGraphPage"));
const ChatbotPage = lazy(() => import("./pages/ChatbotPage"));
const AdminPage = lazy(() => import("./pages/AdminPage"));

function PageLoader() {
  return (
    <div className="flex h-screen items-center justify-center bg-background">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-accent border-t-transparent" />
    </div>
  );
}

// Root route
const rootRoute = createRootRoute();

// Index → redirect to /dashboard
const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/",
  component: () => <Navigate to="/dashboard" />,
});

const loginRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/login",
  component: () => (
    <Suspense fallback={<PageLoader />}>
      <LoginPage />
    </Suspense>
  ),
});

const dashboardRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/dashboard",
  component: () => (
    <ProtectedRoute>
      <Suspense fallback={<PageLoader />}>
        <DashboardPage />
      </Suspense>
    </ProtectedRoute>
  ),
});

const rulesRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/rules",
  component: () => (
    <ProtectedRoute>
      <Suspense fallback={<PageLoader />}>
        <RulesPage />
      </Suspense>
    </ProtectedRoute>
  ),
});

const recommendationsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/recommendations",
  component: () => (
    <ProtectedRoute>
      <Suspense fallback={<PageLoader />}>
        <RecommendationsPage />
      </Suspense>
    </ProtectedRoute>
  ),
});

const uploadRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/upload",
  component: () => (
    <ProtectedRoute requireAdmin>
      <Suspense fallback={<PageLoader />}>
        <UploadPage />
      </Suspense>
    </ProtectedRoute>
  ),
});

const settingsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/settings",
  component: () => (
    <ProtectedRoute>
      <Suspense fallback={<PageLoader />}>
        <SettingsPage />
      </Suspense>
    </ProtectedRoute>
  ),
});

const analyticsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/analytics",
  component: () => (
    <ProtectedRoute>
      <Suspense fallback={<PageLoader />}>
        <AnalyticsPage />
      </Suspense>
    </ProtectedRoute>
  ),
});

const networkGraphRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/network-graph",
  component: () => (
    <ProtectedRoute>
      <Suspense fallback={<PageLoader />}>
        <NetworkGraphPage />
      </Suspense>
    </ProtectedRoute>
  ),
});

const chatbotRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/chatbot",
  component: () => (
    <ProtectedRoute>
      <Suspense fallback={<PageLoader />}>
        <ChatbotPage />
      </Suspense>
    </ProtectedRoute>
  ),
});

const adminRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/admin",
  component: () => (
    <ProtectedRoute requireAdmin>
      <Suspense fallback={<PageLoader />}>
        <AdminPage />
      </Suspense>
    </ProtectedRoute>
  ),
});

const routeTree = rootRoute.addChildren([
  indexRoute,
  loginRoute,
  dashboardRoute,
  rulesRoute,
  recommendationsRoute,
  uploadRoute,
  settingsRoute,
  analyticsRoute,
  networkGraphRoute,
  chatbotRoute,
  adminRoute,
]);

const router = createRouter({ routeTree });

declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }
}

export default function App() {
  return <RouterProvider router={router} />;
}
