import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export type Timestamp = bigint;
export interface TransactionDataset {
    id: DatasetId;
    name: string;
    uploadTimestamp: Timestamp;
    uploadedBy: UserId;
    recordCount: bigint;
}
export interface AssociationRule {
    id: RuleId;
    datasetId: DatasetId;
    support: number;
    lift: number;
    confidence: number;
    antecedent: string;
    consequent: string;
}
export type RuleId = bigint;
export interface AuditEntry {
    id: bigint;
    status: string;
    action: AuditActionType;
    resourceId?: string;
    userId: UserId;
    resourceType?: string;
    timestamp: Timestamp;
    details: string;
}
export type DatasetId = bigint;
export interface DashboardStats {
    totalProducts: bigint;
    avgLift: number;
    topProducts: Array<string>;
    totalDatasets: bigint;
    totalTransactions: bigint;
    totalRules: bigint;
}
export interface InventoryItem {
    reorderPoint: bigint;
    isInStock: boolean;
    lastUpdated: Timestamp;
    productId: string;
    productName: string;
    stockLevel: bigint;
}
export type UserId = Principal;
export interface SystemSettings {
    abTestDurationDays: bigint;
    streamingAutoGenerateRate: bigint;
    nlpServiceEndpoint: string;
    alertThresholdTrending: number;
    pollingIntervalSecs: bigint;
    inventoryWarningLevel: bigint;
    alertThresholdLowSales: number;
}
export interface ChatResponse {
    answer: string;
    intent: ChatIntent;
    confidence: number;
    products: Array<string>;
    rules: Array<bigint>;
}
export interface Recommendation {
    support: number;
    lift: number;
    confidence: number;
    product: string;
}
export interface ChatMessage {
    id: bigint;
    content: string;
    userId: UserId;
    isUser: boolean;
    timestamp: Timestamp;
    sessionId: string;
    relatedProducts: Array<string>;
    relatedRules: Array<bigint>;
}
export interface ProductPair {
    support: number;
    productA: string;
    productB: string;
    coOccurrences: bigint;
}
export interface Alert {
    id: bigint;
    alertType: AlertType;
    title: string;
    metricValue?: number;
    threshold?: number;
    createdAt: Timestamp;
    productId?: string;
    isRead: boolean;
    message: string;
    severity: AlertSeverity;
    isDismissed: boolean;
}
export enum AlertSeverity {
    warning = "warning",
    info = "info",
    critical = "critical"
}
export enum AlertType {
    ruleDecay = "ruleDecay",
    trendingProduct = "trendingProduct",
    newInsight = "newInsight",
    lowSales = "lowSales",
    inventoryWarning = "inventoryWarning"
}
export enum AuditActionType {
    userLogin = "userLogin",
    alertDismissed = "alertDismissed",
    datasetUpload = "datasetUpload",
    inventoryUpdated = "inventoryUpdated",
    recommendationViewed = "recommendationViewed",
    chatbotQuery = "chatbotQuery",
    rulesComputed = "rulesComputed",
    settingsChanged = "settingsChanged",
    roleChanged = "roleChanged"
}
export enum ChatIntent {
    demandForecast = "demandForecast",
    whatSellsWith = "whatSellsWith",
    showMargins = "showMargins",
    recommendBySegment = "recommendBySegment",
    generalQuery = "generalQuery"
}
export enum UserRole {
    admin = "admin",
    analyst = "analyst",
    viewer = "viewer"
}
export enum UserRole__1 {
    admin = "admin",
    user = "user",
    guest = "guest"
}
export interface backendInterface {
    addTransactionDataset(name: string, products: Array<Array<string>>): Promise<DatasetId>;
    assignCallerUserRole(user: Principal, role: UserRole__1): Promise<void>;
    clearChatHistory(sessionId: string): Promise<boolean>;
    computeAssociationRules(datasetId: DatasetId, minSupport: number, minConfidence: number): Promise<bigint>;
    dismissAlert(alertId: bigint): Promise<boolean>;
    exportAuditLogCSV(startTime: Timestamp, endTime: Timestamp): Promise<string>;
    generateAlerts(): Promise<Array<Alert>>;
    generateSyntheticTransaction(): Promise<boolean>;
    getAlertStats(): Promise<{
        total: bigint;
        unread: bigint;
        critical: bigint;
    }>;
    getAlerts(unreadOnly: boolean): Promise<Array<Alert>>;
    getAllUsers(): Promise<Array<[UserId, UserRole]>>;
    getAssociationRules(datasetId: DatasetId): Promise<Array<AssociationRule>>;
    getAuditLog(page: bigint, pageSize: bigint): Promise<{
        total: bigint;
        page: bigint;
        entries: Array<AuditEntry>;
    }>;
    getAuditLogByAction(action: AuditActionType, page: bigint, pageSize: bigint): Promise<{
        total: bigint;
        entries: Array<AuditEntry>;
    }>;
    getAuditLogByUser(userId: UserId, page: bigint, pageSize: bigint): Promise<{
        total: bigint;
        entries: Array<AuditEntry>;
    }>;
    getCallerUserRole(): Promise<UserRole__1>;
    getChatHistory(sessionId: string): Promise<Array<ChatMessage>>;
    getDashboardStats(): Promise<DashboardStats>;
    getInventoryItems(): Promise<Array<InventoryItem>>;
    getRecommendations(productName: string, topN: bigint): Promise<Array<Recommendation>>;
    getStreamingStatus(): Promise<{
        transactionsGenerated: bigint;
        lastGeneratedAt?: Timestamp;
        isRunning: boolean;
    }>;
    getSystemSettings(): Promise<SystemSettings>;
    getTopProductPairs(limit: bigint): Promise<Array<ProductPair>>;
    getTransactionDatasets(): Promise<Array<TransactionDataset>>;
    getUserCount(): Promise<bigint>;
    getUserRole(): Promise<string>;
    isCallerAdmin(): Promise<boolean>;
    logAuditEntry(caller: UserId, action: AuditActionType, resourceId: string | null, resourceType: string | null, details: string): Promise<void>;
    markAlertRead(alertId: bigint): Promise<boolean>;
    queryChatbot(message: string, sessionId: string): Promise<ChatResponse>;
    setUserRole(userId: UserId, role: string): Promise<boolean>;
    toggleStreamingMode(enabled: boolean): Promise<boolean>;
    updateInventoryItem(item: InventoryItem): Promise<boolean>;
    updateSystemSettings(settings: SystemSettings): Promise<boolean>;
    updateUserRole(userId: UserId, newRole: UserRole): Promise<boolean>;
}
